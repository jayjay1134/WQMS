using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace WaterQualityDashboard
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new DashboardForm());
        }
    }

    internal sealed class DashboardForm : Form
    {
        private readonly Color background = Color.FromArgb(7, 17, 31);
        private readonly Color panelColor = Color.FromArgb(15, 25, 43);
        private readonly Color borderColor = Color.FromArgb(32, 46, 66);
        private readonly Color mutedText = Color.FromArgb(159, 183, 217);
        private readonly Color accent = Color.FromArgb(45, 193, 239);
        private const string DefaultFirebaseApiKey = "AIzaSyDUfgCEO-ZVW_eudMRDvUD4D0p-Kc3uQeg";
        private const string DefaultFirebaseDatabaseUrl = "https://water-monitoring-b46f4-default-rtdb.firebaseio.com";
        private readonly TableLayoutPanel content;
        private readonly Label pageTitle;
        private readonly Button[] navigationButtons;
        private readonly Label statusLabel;
        private readonly Label[] metricValues = new Label[5];
        private readonly Label[] latestValues = new Label[4];
        private readonly JavaScriptSerializer json = new JavaScriptSerializer();
        private FirebaseSession firebaseSession;
        private System.Threading.Timer refreshTimer;
        private int requestInFlight;

        public DashboardForm()
        {
            Text = "WQMS - Advanced Water Quality Monitoring";
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(980, 620);
            ClientSize = new Size(1360, 760);
            BackColor = background;
            ForeColor = Color.White;
            Font = new Font("Segoe UI", 10F);
            FormClosed += delegate
            {
                if (refreshTimer != null)
                    refreshTimer.Dispose();
                refreshTimer = null;
                firebaseSession = null;
            };

            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1,
                BackColor = background,
                Margin = Padding.Empty
            };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 250));
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            Controls.Add(root);

            var sidebar = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(3, 9, 24),
                Padding = new Padding(24, 22, 20, 18)
            };
            root.Controls.Add(sidebar, 0, 0);

            var sidebarLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                BackColor = Color.Transparent,
                Margin = Padding.Empty
            };
            sidebarLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
            sidebarLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            sidebarLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
            sidebar.Controls.Add(sidebarLayout);

            var brand = new Label
            {
                Text = "WQMS",
                Dock = DockStyle.Fill,
                ForeColor = accent,
                Font = new Font("Segoe UI", 20F, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft
            };
            sidebarLayout.Controls.Add(brand, 0, 0);

            var navPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                BackColor = Color.Transparent,
                Padding = new Padding(0, 8, 0, 0),
                Margin = Padding.Empty
            };
            sidebarLayout.Controls.Add(navPanel, 0, 1);

            string[] pages = { "Dashboard", "Sensor Data", "Alerts", "Reports", "Thresholds" };
            navigationButtons = new Button[pages.Length];
            for (int i = 0; i < pages.Length; i++)
            {
                int pageIndex = i;
                var button = CreateNavButton(pages[i]);
                button.Click += delegate { ShowPage(pageIndex); };
                navigationButtons[i] = button;
                navPanel.Controls.Add(button);
            }
            navigationButtons[0].ForeColor = Color.White;
            navigationButtons[0].BackColor = Color.FromArgb(13, 27, 48);

            var logout = CreateNavButton("Logout");
            logout.ForeColor = Color.FromArgb(255, 197, 207);
            logout.Click += delegate { Close(); };
            sidebarLayout.Controls.Add(logout, 0, 2);

            var main = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(28, 22, 28, 16),
                BackColor = background
            };
            root.Controls.Add(main, 1, 0);

            var mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                BackColor = background,
                Margin = Padding.Empty
            };
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 88));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 154));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            main.Controls.Add(mainLayout);

            var header = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 3,
                RowCount = 1,
                BackColor = background,
                Margin = Padding.Empty
            };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 138));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 148));
            mainLayout.Controls.Add(header, 0, 0);

            var heading = new Panel { Dock = DockStyle.Fill, BackColor = background };
            header.Controls.Add(heading, 0, 0);
            pageTitle = new Label
            {
                Text = "Advanced Water Quality Monitoring Dashboard",
                Dock = DockStyle.Top,
                Height = 40,
                Font = new Font("Segoe UI", 21F, FontStyle.Bold),
                ForeColor = Color.FromArgb(241, 245, 251),
                AutoEllipsis = true
            };
            heading.Controls.Add(pageTitle);
            heading.Controls.Add(new Label
            {
                Text = "Cloud-based IoT monitoring using ESP32, Firebase, and GitHub Pages.",
                Dock = DockStyle.Top,
                Height = 27,
                ForeColor = mutedText,
                Font = new Font("Segoe UI", 10.5F)
            });

            statusLabel = new Label
            {
                Text = "NOT CONNECTED",
                Dock = DockStyle.None,
                Anchor = AnchorStyles.Right | AnchorStyles.Top,
                Location = new Point(3, 16),
                Size = new Size(128, 36),
                BackColor = Color.FromArgb(44, 37, 24),
                ForeColor = Color.FromArgb(245, 201, 116),
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter
            };
            statusLabel.Paint += delegate(object sender, PaintEventArgs e)
            {
                using (var pen = new Pen(Color.FromArgb(16, 117, 82)))
                using (var path = RoundedRectangle(statusLabel.ClientRectangle, 18))
                {
                    e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    e.Graphics.DrawPath(pen, path);
                }
            };
            header.Controls.Add(statusLabel, 1, 0);
            var connectButton = new Button
            {
                Text = "Connect Firebase",
                Dock = DockStyle.None,
                Anchor = AnchorStyles.Right | AnchorStyles.Top,
                Location = new Point(3, 12),
                Size = new Size(140, 42),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(13, 87, 119),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            connectButton.FlatAppearance.BorderSize = 0;
            connectButton.Click += delegate { ToggleFirebaseConnection(); };
            header.Controls.Add(connectButton, 2, 0);

            mainLayout.Controls.Add(BuildMetricCards(), 0, 1);
            content = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 1,
                BackColor = background,
                Margin = Padding.Empty
            };
            mainLayout.Controls.Add(content, 0, 2);
            ShowPage(0);
        }

        private Button CreateNavButton(string text)
        {
            return new Button
            {
                Text = text,
                Width = 202,
                Height = 48,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(14, 0, 0, 0),
                Margin = new Padding(0, 0, 0, 6),
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0, MouseOverBackColor = Color.FromArgb(13, 27, 48) },
                BackColor = Color.Transparent,
                ForeColor = Color.FromArgb(207, 217, 231),
                Font = new Font("Segoe UI", 10F),
                Cursor = Cursors.Hand
            };
        }

        private Control BuildMetricCards()
        {
            var metrics = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 5,
                RowCount = 1,
                BackColor = background,
                Margin = Padding.Empty
            };
            for (int i = 0; i < 5; i++)
                metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));

            string[] names = { "pH Level", "Turbidity", "Temperature", "TDS", "Dissolved Oxygen" };
            for (int metricIndex = 0; metricIndex < names.Length; metricIndex++)
            {
                string name = names[metricIndex];
                var card = new RoundedPanel
                {
                    Dock = DockStyle.Fill,
                    BackColor = panelColor,
                    BorderColor = borderColor,
                    Radius = 22,
                    Padding = new Padding(20, 16, 12, 12),
                    Margin = new Padding(0, 0, 14, 0)
                };
                var layout = new TableLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    ColumnCount = 1,
                    RowCount = 3,
                    BackColor = Color.Transparent,
                    Margin = Padding.Empty
                };
                layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
                layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
                layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 27));
                card.Controls.Add(layout);
                layout.Controls.Add(new Label
                {
                    Text = name,
                    Dock = DockStyle.Fill,
                    ForeColor = mutedText,
                    Font = new Font("Segoe UI", 10F),
                    AutoEllipsis = true
                }, 0, 0);
                metricValues[metricIndex] = new Label
                {
                    Text = "--",
                    Dock = DockStyle.Fill,
                    ForeColor = Color.FromArgb(238, 243, 251),
                    Font = new Font("Segoe UI", 23F, FontStyle.Bold),
                    TextAlign = ContentAlignment.MiddleLeft
                };
                layout.Controls.Add(metricValues[metricIndex], 0, 1);
                layout.Controls.Add(new Label
                {
                    Text = "Safe: --",
                    Dock = DockStyle.Fill,
                    ForeColor = mutedText,
                    Font = new Font("Segoe UI", 9F)
                }, 0, 2);
                metrics.Controls.Add(card, metrics.Controls.Count, 0);
            }
            return metrics;
        }

        private void ShowPage(int selected)
        {
            for (int i = 0; i < navigationButtons.Length; i++)
            {
                navigationButtons[i].BackColor = i == selected
                    ? Color.FromArgb(13, 27, 48)
                    : Color.Transparent;
                navigationButtons[i].ForeColor = i == selected
                    ? Color.White
                    : Color.FromArgb(207, 217, 231);
            }

            content.SuspendLayout();
            content.Controls.Clear();
            if (selected == 0)
            {
                pageTitle.Text = "Advanced Water Quality Monitoring Dashboard";
                content.ColumnCount = 2;
                content.ColumnStyles.Clear();
                content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 68F));
                content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32F));
                content.Controls.Add(BuildGraphCard(), 0, 0);
                content.Controls.Add(BuildLatestCard(), 1, 0);
            }
            else
            {
                pageTitle.Text = navigationButtons[selected].Text;
                content.ColumnCount = 1;
                content.ColumnStyles.Clear();
                content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
                var card = NewCard();
                var message = new Label
                {
                    Dock = DockStyle.Fill,
                    Text = "Waiting for sensor data to become available.",
                    ForeColor = mutedText,
                    Font = new Font("Segoe UI", 12F),
                    TextAlign = ContentAlignment.MiddleCenter
                };
                card.Controls.Add(message);
                content.Controls.Add(card, 0, 0);
            }
            content.ResumeLayout();
        }

        private void ToggleFirebaseConnection()
        {
            if (firebaseSession != null)
            {
                if (refreshTimer != null)
                    refreshTimer.Change(Timeout.Infinite, Timeout.Infinite);
                refreshTimer = null;
                firebaseSession = null;
                statusLabel.Text = "NOT CONNECTED";
                statusLabel.BackColor = Color.FromArgb(44, 37, 24);
                statusLabel.ForeColor = Color.FromArgb(245, 201, 116);
                for (int i = 0; i < metricValues.Length; i++)
                    metricValues[i].Text = "--";
                for (int i = 0; i < latestValues.Length; i++)
                    latestValues[i].Text = latestValues[i].Text.Substring(0, latestValues[i].Text.IndexOf(':') + 1) + " --";
                return;
            }

            using (var dialog = new FirebaseLoginDialog(DefaultFirebaseDatabaseUrl, DefaultFirebaseApiKey))
            {
                if (dialog.ShowDialog(this) != DialogResult.OK)
                    return;

                firebaseSession = new FirebaseSession(dialog.DatabaseUrl, dialog.ApiKey, dialog.Email, dialog.Password);
            }

            statusLabel.Text = "CONNECTING";
            statusLabel.BackColor = Color.FromArgb(10, 43, 39);
            statusLabel.ForeColor = Color.FromArgb(100, 237, 177);
            QueueFirebaseRefresh();
            refreshTimer = new System.Threading.Timer(
                delegate { QueueFirebaseRefresh(); },
                null,
                5000,
                5000);
        }

        private void QueueFirebaseRefresh()
        {
            if (firebaseSession == null || Interlocked.Exchange(ref requestInFlight, 1) != 0)
                return;

            FirebaseSession session = firebaseSession;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    if (session.IdToken == null ||
                        DateTime.UtcNow - session.AuthenticatedAt > TimeSpan.FromMinutes(45))
                    {
                        Authenticate(session);
                    }

                    string url = session.DatabaseUrl + "/sensorData/latest.json?auth=" +
                                 Uri.EscapeDataString(session.IdToken);
                    var reading = json.Deserialize<Dictionary<string, object>>(SendRequest(url, "GET", null));
                    if (reading == null)
                        throw new InvalidDataException("No sensor reading exists at /sensorData/latest.");

                    if (!IsDisposed && IsHandleCreated)
                        BeginInvoke((MethodInvoker)delegate
                        {
                            if (firebaseSession != session)
                                return;
                            statusLabel.Text = "LIVE";
                            statusLabel.BackColor = Color.FromArgb(10, 43, 39);
                            statusLabel.ForeColor = Color.FromArgb(100, 237, 177);
                            metricValues[0].Text = FormatReading(reading, "ph", 2);
                            metricValues[1].Text = FormatReading(reading, "turbidity", 1);
                            metricValues[2].Text = FormatReading(reading, "temperature", 2);
                            metricValues[3].Text = FormatReading(reading, "tds", 1);
                            metricValues[4].Text = FormatReading(reading, "dissolvedOxygen", 2);
                            latestValues[0].Text = "Device: " + ReadText(reading, "deviceId");
                            latestValues[1].Text = "Status: " + ReadText(reading, "status");
                            latestValues[2].Text = "Remarks: " + ReadText(reading, "remarks");
                            latestValues[3].Text = "Date/Time: " + FormatTimestamp(reading);
                        });
                }
                catch (Exception error)
                {
                    if (!IsDisposed && IsHandleCreated)
                        BeginInvoke((MethodInvoker)delegate
                        {
                            if (firebaseSession != session)
                                return;
                            statusLabel.Text = "ERROR";
                            statusLabel.BackColor = Color.FromArgb(55, 25, 35);
                            statusLabel.ForeColor = Color.FromArgb(255, 170, 170);
                            latestValues[3].Text = "Date/Time: " + FriendlyFirebaseError(error);
                        });
                }
                finally
                {
                    Interlocked.Exchange(ref requestInFlight, 0);
                }
            });
        }

        private void Authenticate(FirebaseSession session)
        {
            string url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" +
                         Uri.EscapeDataString(session.ApiKey);
            var request = new Dictionary<string, object>();
            request["email"] = session.Email;
            request["password"] = session.Password;
            request["returnSecureToken"] = true;
            var response = json.Deserialize<Dictionary<string, object>>(
                SendRequest(url, "POST", json.Serialize(request)));
            object token;
            if (response == null || !response.TryGetValue("idToken", out token) || token == null)
                throw new InvalidDataException("Firebase sign-in response did not include an ID token.");

            session.IdToken = Convert.ToString(token);
            session.AuthenticatedAt = DateTime.UtcNow;
        }

        private static string SendRequest(string url, string method, string body)
        {
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = method;
            request.Accept = "application/json";
            request.ContentType = "application/json; charset=utf-8";
            request.Timeout = 15000;
            request.ReadWriteTimeout = 15000;

            if (body != null)
            {
                byte[] data = Encoding.UTF8.GetBytes(body);
                request.ContentLength = data.Length;
                using (Stream stream = request.GetRequestStream())
                    stream.Write(data, 0, data.Length);
            }

            try
            {
                using (var response = (HttpWebResponse)request.GetResponse())
                using (var reader = new StreamReader(response.GetResponseStream()))
                    return reader.ReadToEnd();
            }
            catch (WebException exception)
            {
                var response = exception.Response as HttpWebResponse;
                if (response == null)
                    throw;
                using (response)
                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    string bodyText = reader.ReadToEnd();
                    throw new InvalidOperationException(
                        "Firebase HTTP " + (int)response.StatusCode + ": " + bodyText,
                        exception);
                }
            }
        }

        private static string FormatReading(Dictionary<string, object> reading, string key, int decimals)
        {
            object value;
            double number;
            if (!reading.TryGetValue(key, out value) || value == null ||
                !Double.TryParse(Convert.ToString(value), System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out number))
                return "--";

            return number.ToString("F" + decimals, System.Globalization.CultureInfo.InvariantCulture);
        }

        private static string ReadText(Dictionary<string, object> reading, string key)
        {
            object value;
            return reading.TryGetValue(key, out value) && value != null
                ? Convert.ToString(value)
                : "--";
        }

        private static string FormatTimestamp(Dictionary<string, object> reading)
        {
            object value;
            double seconds;
            if (!reading.TryGetValue("timestamp", out value) || value == null ||
                !Double.TryParse(Convert.ToString(value), System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out seconds) ||
                seconds < 0 || seconds > 253402300799)
                return "--";

            return new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)
                .AddSeconds(seconds).ToLocalTime().ToString("g");
        }

        private static string FriendlyFirebaseError(Exception error)
        {
            string message = error.Message;
            if (message.IndexOf("INVALID_PASSWORD", StringComparison.OrdinalIgnoreCase) >= 0 ||
                message.IndexOf("INVALID_LOGIN_CREDENTIALS", StringComparison.OrdinalIgnoreCase) >= 0 ||
                message.IndexOf("EMAIL_NOT_FOUND", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Sign-in failed. Check the Firebase email and password.";
            if (message.IndexOf("API_KEY_INVALID", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Firebase API key is invalid.";
            if (message.IndexOf("Permission denied", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Firebase denied access. Check database rules.";
            if (message.IndexOf("No sensor reading", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Waiting for ESP32 data at /sensorData/latest.";
            return message;
        }

        private Control BuildGraphCard()
        {
            var card = NewCard();
            card.Padding = new Padding(22, 18, 18, 18);
            var title = new Label
            {
                Text = "Real-Time Sensor Graph",
                Dock = DockStyle.Top,
                Height = 50,
                ForeColor = Color.FromArgb(241, 245, 251),
                Font = new Font("Segoe UI", 16F, FontStyle.Bold)
            };
            card.Controls.Add(title);
            return card;
        }

        private Control BuildLatestCard()
        {
            var card = NewCard();
            card.Padding = new Padding(22, 18, 22, 18);
            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 5,
                BackColor = Color.Transparent,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 62));
            for (int i = 1; i < 5; i++)
                layout.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            card.Controls.Add(layout);
            layout.Controls.Add(new Label
            {
                Text = "Latest Reading",
                Dock = DockStyle.Fill,
                ForeColor = Color.FromArgb(241, 245, 251),
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft
            }, 0, 0);

            string[] readingNames = { "Device", "Status", "Remarks", "Date/Time" };
            for (int i = 0; i < readingNames.Length; i++)
            {
                int readingIndex = i;
                var item = new Panel
                {
                    Dock = DockStyle.Fill,
                    BackColor = Color.FromArgb(7, 15, 32),
                    Margin = new Padding(0, 3, 0, 8),
                    Padding = new Padding(12, 0, 8, 0)
                };
                item.Paint += delegate(object sender, PaintEventArgs e)
                {
                    using (var pen = new Pen(borderColor))
                    using (var path = RoundedRectangle(item.ClientRectangle, 14))
                    {
                        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                        e.Graphics.DrawPath(pen, path);
                    }
                };
                latestValues[readingIndex] = new Label
                {
                    Text = readingNames[readingIndex] + ": --",
                    Dock = DockStyle.Fill,
                    ForeColor = Color.FromArgb(230, 237, 248),
                    Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                    TextAlign = ContentAlignment.MiddleLeft
                };
                item.Controls.Add(latestValues[readingIndex]);
                layout.Controls.Add(item, 0, layout.Controls.Count);
            }
            return card;
        }

        private RoundedPanel NewCard()
        {
            return new RoundedPanel
            {
                Dock = DockStyle.Fill,
                BackColor = panelColor,
                BorderColor = borderColor,
                Radius = 23,
                Margin = new Padding(0, 0, 14, 0)
            };
        }

        internal static GraphicsPath RoundedRectangle(Rectangle bounds, int radius)
        {
            int diameter = radius * 2;
            var path = new GraphicsPath();
            path.AddArc(bounds.Left, bounds.Top, diameter, diameter, 180, 90);
            path.AddArc(bounds.Right - diameter - 1, bounds.Top, diameter, diameter, 270, 90);
            path.AddArc(bounds.Right - diameter - 1, bounds.Bottom - diameter - 1, diameter, diameter, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - diameter - 1, diameter, diameter, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    internal sealed class FirebaseSession
    {
        public readonly string DatabaseUrl;
        public readonly string ApiKey;
        public readonly string Email;
        public readonly string Password;
        public string IdToken;
        public DateTime AuthenticatedAt;

        public FirebaseSession(string databaseUrl, string apiKey, string email, string password)
        {
            DatabaseUrl = databaseUrl.TrimEnd('/');
            ApiKey = apiKey;
            Email = email;
            Password = password;
        }
    }

    internal sealed class FirebaseLoginDialog : Form
    {
        private readonly TextBox databaseUrlInput;
        private readonly TextBox apiKeyInput;
        private readonly TextBox emailInput;
        private readonly TextBox passwordInput;

        public string DatabaseUrl { get { return databaseUrlInput.Text.Trim(); } }
        public string ApiKey { get { return apiKeyInput.Text.Trim(); } }
        public string Email { get { return emailInput.Text.Trim(); } }
        public string Password { get { return passwordInput.Text; } }

        public FirebaseLoginDialog(string databaseUrl, string apiKey)
        {
            Text = "Connect to Firebase";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(520, 390);
            BackColor = Color.FromArgb(15, 25, 43);
            ForeColor = Color.FromArgb(241, 245, 251);
            Font = new Font("Segoe UI", 10F);

            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 7,
                Padding = new Padding(22),
                BackColor = BackColor
            };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 88));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
            Controls.Add(layout);

            var heading = new Label
            {
                Text = "Sign in with your Firebase user",
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 15F, FontStyle.Bold),
                ForeColor = Color.FromArgb(45, 193, 239),
                TextAlign = ContentAlignment.MiddleLeft
            };
            layout.Controls.Add(heading, 0, 0);
            layout.Controls.Add(FieldLabel("Realtime Database URL"), 0, 1);
            databaseUrlInput = Field(databaseUrl);
            layout.Controls.Add(databaseUrlInput, 0, 2);
            layout.Controls.Add(FieldLabel("Firebase Web API key"), 0, 3);
            apiKeyInput = Field(apiKey);
            layout.Controls.Add(apiKeyInput, 0, 4);
            var credentials = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 2,
                BackColor = BackColor,
                Margin = Padding.Empty
            };
            credentials.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            credentials.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            credentials.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
            credentials.RowStyles.Add(new RowStyle(SizeType.Absolute, 45));
            emailInput = Field("");
            passwordInput = Field("");
            passwordInput.UseSystemPasswordChar = true;
            var emailPanel = new Panel { Dock = DockStyle.Fill, BackColor = BackColor, Margin = Padding.Empty };
            emailPanel.Controls.Add(emailInput);
            emailPanel.Controls.Add(FieldLabel("Email"));
            emailPanel.Controls[0].Dock = DockStyle.Bottom;
            emailPanel.Controls[0].Height = 25;
            emailPanel.Controls[1].Dock = DockStyle.Top;
            emailPanel.Controls[1].Height = 17;
            var passwordPanel = new Panel { Dock = DockStyle.Fill, BackColor = BackColor, Margin = Padding.Empty };
            passwordPanel.Controls.Add(passwordInput);
            passwordPanel.Controls.Add(FieldLabel("Password"));
            passwordPanel.Controls[0].Dock = DockStyle.Bottom;
            passwordPanel.Controls[0].Height = 25;
            passwordPanel.Controls[1].Dock = DockStyle.Top;
            passwordPanel.Controls[1].Height = 17;
            credentials.Controls.Add(emailPanel, 0, 0);
            credentials.Controls.Add(passwordPanel, 1, 0);
            var cancel = new Button
            {
                Text = "Cancel",
                DialogResult = DialogResult.Cancel,
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(32, 46, 66),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(0, 5, 8, 0)
            };
            var connect = new Button
            {
                Text = "Sign in and connect",
                DialogResult = DialogResult.OK,
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(13, 87, 119),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(8, 5, 0, 0)
            };
            cancel.FlatAppearance.BorderSize = 0;
            connect.FlatAppearance.BorderSize = 0;
            credentials.Controls.Add(cancel, 0, 1);
            credentials.Controls.Add(connect, 1, 1);
            layout.Controls.Add(credentials, 0, 6);
            AcceptButton = connect;
            CancelButton = cancel;

            connect.Click += delegate
            {
                Uri uri;
                if (!Uri.TryCreate(DatabaseUrl, UriKind.Absolute, out uri) ||
                    uri.Scheme != Uri.UriSchemeHttps ||
                    !(uri.Host.EndsWith(".firebaseio.com", StringComparison.OrdinalIgnoreCase) ||
                      uri.Host.EndsWith(".firebasedatabase.app", StringComparison.OrdinalIgnoreCase)) ||
                    String.IsNullOrWhiteSpace(ApiKey) ||
                    String.IsNullOrWhiteSpace(Email) ||
                    String.IsNullOrWhiteSpace(Password))
                {
                    MessageBox.Show(this,
                        "Enter your Firebase database URL, Web API key, and Email/Password user.",
                        "Check Firebase settings",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    DialogResult = DialogResult.None;
                }
            };
        }

        private static Label FieldLabel(string value)
        {
            return new Label
            {
                Text = value,
                Dock = DockStyle.Fill,
                ForeColor = Color.FromArgb(159, 183, 217),
                TextAlign = ContentAlignment.BottomLeft
            };
        }

        private static TextBox Field(string value)
        {
            return new TextBox
            {
                Text = value,
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(7, 15, 32),
                ForeColor = Color.FromArgb(241, 245, 251),
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(0, 2, 0, 4)
            };
        }
    }

    internal sealed class RoundedPanel : Panel
    {
        public int Radius { get; set; }
        public Color BorderColor { get; set; }

        public RoundedPanel()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Width <= 1 || Height <= 1)
                return;

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle bounds = new Rectangle(0, 0, Width - 1, Height - 1);
            using (var path = DashboardForm.RoundedRectangle(bounds, Radius))
            using (var pen = new Pen(BorderColor))
            {
                e.Graphics.DrawPath(pen, path);
            }
        }
    }
}
