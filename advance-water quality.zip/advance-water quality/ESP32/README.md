# WQMS ESP32 firmware

`ESP32.ino` samples analog pH, turbidity, TDS, and dissolved-oxygen probes
plus a DS18B20 temperature sensor. It uploads readings every five seconds to
Firebase Realtime Database. When an SD card is installed, each reading is first
saved locally and then uploaded to both `/sensorData/history/<recordId>` and
`/sensorData/latest`. If Wi-Fi or Firebase is unavailable, sampling continues
and queued readings are uploaded in order after secure connectivity returns.

## Hardware and default pins

| Sensor signal | ESP32 pin |
| --- | --- |
| pH analog output | GPIO 34 |
| Turbidity analog output | GPIO 35 |
| TDS analog output | GPIO 32 |
| Dissolved-oxygen analog output | GPIO 33 |
| DS18B20 data | GPIO 4 |
| microSD module CS | GPIO 5 |
| microSD module SCK | GPIO 18 |
| microSD module MISO | GPIO 19 |
| microSD module MOSI | GPIO 23 |

Connect all sensor grounds to ESP32 ground. The DS18B20 data line needs a
4.7 kOhm pull-up resistor to 3.3 V. These ADC pins are on ADC1, which can be
used while Wi-Fi is active.

**Check voltage before connecting a sensor:** ESP32 GPIOs are not 5 V tolerant.
Use an appropriate level shifter or voltage divider if a sensor board can
output more than 3.3 V. Follow each probe manufacturer's power and isolation
requirements.

### microSD offline queue

Use a microSD SPI module and a FAT32-formatted card. The firmware uses the
ESP32's default VSPI pins shown above and GPIO 5 for chip select. Check your
specific ESP32 board and SD module before wiring; power the module as its
manufacturer specifies, and ensure its logic signals are safe for 3.3 V ESP32
GPIOs. Never connect a 5 V logic output directly to an ESP32 pin.

The sketch creates `/queue` automatically. It writes each record to a temporary
file and renames it into a numbered shard directory, so an interrupted write
does not appear as a complete record. The SD card keeps data across resets;
records are removed only after both the history and latest Firebase writes
succeed. Repeated history writes use the same record ID, so retrying a partially
completed upload does not create duplicate history entries. Queue data is not
automatically deleted based on age; size the card for the expected outage and
check Serial Monitor errors if it becomes full or unavailable.

Firebase history grows separately from the local queue. Configure a retention
or cleanup policy in your Firebase project if you need a bounded online
history.

## Arduino IDE setup

1. Install the ESP32 board package by Espressif Systems and select your ESP32
   board and serial port.
2. Install the `ArduinoJson` library (version 7), `OneWire`, and
   `DallasTemperature` from Library Manager. `WiFi`, `HTTPClient`, and
   `WiFiClientSecure` are included with the ESP32 board package.
3. Copy `secrets.example.h` to `secrets.h` in this sketch folder. Fill in your
   Wi-Fi name/password and the email/password of your Firebase Authentication
   user. The Firebase Web API key, database URL, and Google Trust Services root
   certificate are prefilled from this project's Firebase configuration.
   Keep `secrets.h` private.
4. Keep certificate validation enabled; do not use `setInsecure()`.
5. Enable Email/Password sign-in in Firebase Authentication and create the
   firmware user. In Firebase Console, open **Authentication > Users** and
   copy that user's **UID** for the rule below. The UID is not the Web API key.
6. Merge the following permissions into your existing Realtime Database rules,
   replacing `YOUR_ESP32_USER_UID` with the firmware user's UID. Preserve any
   other rules your mobile app needs:

   ```json
   {
     "rules": {
       "sensorData": {
         ".read": "auth != null",
         "latest": {
           ".write": "auth != null && auth.uid === 'YOUR_ESP32_USER_UID'"
         },
         "history": {
           ".write": "auth != null && auth.uid === 'YOUR_ESP32_USER_UID'"
         }
       }
     }
   }
   ```

   These rules allow signed-in users to read sensor data but only the ESP32
   account to write it. Adjust read permissions to match your app's access
   requirements. Do not make the database public.
7. Upload the sketch, open Serial Monitor at 115200 baud, and calibrate the
   probes before using readings for decisions. On startup, confirm that the
   monitor reports the SD card ready; during an outage it should report that
   each reading was saved, then report successful Firebase authentication and
   uploads after connectivity returns.

The API key identifies the Firebase project; it is not a substitute for database
authorization. Never put service-account credentials or database secrets in
device firmware. Restrict the Firebase user's database permissions to only the
paths it needs.

## Calibration

Sensor boards and probes have different transfer curves. The values in the
sketch are example starting points, not validated measurements:

- Set `PH_VOLTAGE_AT_7` and `PH_VOLTAGE_AT_4` from buffer-solution calibration.
- The turbidity conversion is a common analog-module approximation; calibrate it
  against known standards and the exact module, or replace `readTurbidityNtu`.
- The TDS equation is a common analog TDS-module curve with temperature
  compensation. Calibrate against a known conductivity/TDS solution.
- Set `DO_VOLTAGE_AT_ZERO`, `DO_VOLTAGE_AT_SATURATION`, and
  `DO_SATURATION_MG_L` using the dissolved-oxygen probe manufacturer's
  procedure. Saturation depends on water temperature, pressure, and salinity;
  replace the example constant as needed.

Do not use uncalibrated readings for drinking-water, medical, or safety
decisions.

## Firebase data shape

The sketch replaces `/sensorData/latest` with the newest JSON record and keeps
individual readings under `/sensorData/history/<recordId>`. A record looks
like:

```json
{
  "recordId": "wqms-esp32-01-000000000001",
  "deviceId": "wqms-esp32-01",
  "ph": 7.0,
  "turbidity": 0.0,
  "temperature": 25.0,
  "tds": 0.0,
  "dissolvedOxygen": 8.26,
  "status": "online",
  "remarks": "Sensor reading",
  "timestamp": 1791360000,
  "uploadedAt": 1791360005
}
```

`uploadedAt` is added when a record is uploaded. If the device has not acquired
network time yet, it waits before making TLS requests; sensor sampling and SD
buffering continue meanwhile. Authentication retries are rate-limited rather
than sent on every loop iteration.

The existing Windows dashboard is currently a static UI and does not read
Firebase yet; this firmware publishes data to the database but does not by
itself connect the desktop app.
