#include <Arduino.h>
#include <ArduinoJson.h>
#include <DallasTemperature.h>
#include <FS.h>
#include <HTTPClient.h>
#include <OneWire.h>
#include <SD.h>
#include <SPI.h>
#include <string.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <time.h>

#if defined(__has_include)
  #if __has_include("secrets.h")
    #include "secrets.h"
  #elif __has_include("secrets.example.h")
    #include "secrets.example.h"
  #else
    const char WIFI_SSID[] = "";
    const char WIFI_PASSWORD[] = "";
    const char FIREBASE_API_KEY[] = "";
    const char FIREBASE_USER_EMAIL[] = "";
    const char FIREBASE_USER_PASSWORD[] = "";
    const char FIREBASE_DATABASE_URL[] = "";
    const char FIREBASE_ROOT_CA[] = "";
  #endif
#else
  #include "secrets.h"
#endif

namespace
{
const uint8_t PH_PIN = 34;
const uint8_t TURBIDITY_PIN = 35;
const uint8_t TDS_PIN = 32;
const uint8_t DISSOLVED_OXYGEN_PIN = 33;
const uint8_t TEMPERATURE_PIN = 4;
const uint8_t SD_CS_PIN = 5;

const uint32_t SAMPLE_INTERVAL_MS = 5000;
const uint32_t TOKEN_REAUTH_INTERVAL_MS = 45UL * 60UL * 1000UL;
const uint32_t AUTH_RETRY_INTERVAL_MS = 30000;
const uint32_t WIFI_RETRY_INTERVAL_MS = 10000;
const uint8_t MAX_BACKLOG_UPLOADS_PER_LOOP = 1;
const char DEVICE_ID[] = "wqms-esp32-01";
const char DATABASE_LATEST_PATH[] = "/sensorData/latest.json";
const char DATABASE_HISTORY_PATH[] = "/sensorData/history/";
const char QUEUE_DIRECTORY[] = "/queue";
const char QUEUE_TEMP_PATH[] = "/queue/writing.tmp";
const char SEQUENCE_TEMP_PATH[] = "/queue-sequence.tmp";

// Replace these example voltages with readings from your calibrated probes.
const float PH_VOLTAGE_AT_7 = 2.50f;
const float PH_VOLTAGE_AT_4 = 3.00f;
const float DO_VOLTAGE_AT_ZERO = 0.00f;
const float DO_VOLTAGE_AT_SATURATION = 2.00f;
const float DO_SATURATION_MG_L = 8.26f;

OneWire oneWire(TEMPERATURE_PIN);
DallasTemperature temperatureSensor(&oneWire);
String idToken;
uint32_t lastSampleAt = 0;
uint32_t lastAuthenticationAt = 0;
uint32_t lastAuthenticationAttemptAt = 0;
uint32_t lastWifiRetryAt = 0;
uint32_t lastTimeWarningAt = 0;
uint64_t queueSequence = 0;
bool sdReady = false;
bool wasWifiConnected = false;
bool networkTimeReady = false;
bool authenticationAttempted = false;

bool isQueueShardName(const String &name);

float readVoltage(uint8_t pin)
{
  uint32_t totalMillivolts = 0;
  const uint8_t sampleCount = 16;

  for (uint8_t i = 0; i < sampleCount; ++i)
  {
    totalMillivolts += analogReadMilliVolts(pin);
    delay(4);
  }

  return (totalMillivolts / static_cast<float>(sampleCount)) / 1000.0f;
}

float readPh(float voltage)
{
  const float voltsPerPh = (PH_VOLTAGE_AT_4 - PH_VOLTAGE_AT_7) / 3.0f;
  return 7.0f + (PH_VOLTAGE_AT_7 - voltage) / voltsPerPh;
}

float readTurbidityNtu(float voltage)
{
  // Common analog turbidity-module curve; calibrate for the exact probe.
  float ntu = -1120.4f * voltage * voltage + 5742.3f * voltage - 4352.9f;
  return constrain(ntu, 0.0f, 3000.0f);
}

float readTdsPpm(float voltage, float temperatureC)
{
  const float compensation = 1.0f + 0.02f * (temperatureC - 25.0f);
  const float compensatedVoltage = voltage / compensation;
  const float voltageCubed = compensatedVoltage * compensatedVoltage * compensatedVoltage;
  return (133.42f * voltageCubed -
          255.86f * compensatedVoltage * compensatedVoltage +
          857.39f * compensatedVoltage) * 0.5f;
}

float readDissolvedOxygen(float voltage)
{
  const float voltsPerMgL = DO_VOLTAGE_AT_SATURATION / DO_SATURATION_MG_L;
  return constrain((voltage - DO_VOLTAGE_AT_ZERO) / voltsPerMgL, 0.0f, 20.0f);
}

String urlEncode(const String &value)
{
  const char hex[] = "0123456789ABCDEF";
  String encoded;
  encoded.reserve(value.length() * 3);

  for (size_t i = 0; i < value.length(); ++i)
  {
    const uint8_t c = static_cast<uint8_t>(value[i]);
    const bool unreserved = (c >= 'a' && c <= 'z') ||
                            (c >= 'A' && c <= 'Z') ||
                            (c >= '0' && c <= '9') ||
                            c == '-' || c == '_' || c == '.' || c == '~';
    if (unreserved)
    {
      encoded += static_cast<char>(c);
    }
    else
    {
      encoded += '%';
      encoded += hex[c >> 4];
      encoded += hex[c & 0x0F];
    }
  }
  return encoded;
}

bool authenticate()
{
  WiFiClientSecure client;
  client.setCACert(FIREBASE_ROOT_CA);

  const String url = String("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=") +
                     FIREBASE_API_KEY;
  HTTPClient http;
  if (!http.begin(client, url))
  {
    Serial.println("ERROR: Could not start Firebase sign-in request.");
    return false;
  }

  http.addHeader("Content-Type", "application/json");
  JsonDocument request;
  request["email"] = FIREBASE_USER_EMAIL;
  request["password"] = FIREBASE_USER_PASSWORD;
  request["returnSecureToken"] = true;
  String requestBody;
  serializeJson(request, requestBody);

  const int statusCode = http.POST(requestBody);
  const String responseBody = http.getString();
  http.end();

  if (statusCode < 200 || statusCode >= 300)
  {
    Serial.printf("ERROR: Firebase sign-in failed (HTTP %d): %s\n",
                  statusCode, responseBody.c_str());
    return false;
  }

  JsonDocument response;
  const DeserializationError error = deserializeJson(response, responseBody);
  if (error || !response["idToken"].is<const char *>())
  {
    Serial.printf("ERROR: Invalid Firebase sign-in response: %s\n",
                  error ? error.c_str() : "missing idToken");
    return false;
  }

  idToken = response["idToken"].as<String>();
  lastAuthenticationAt = millis();
  Serial.println("Firebase authentication successful.");
  return true;
}

void authenticateIfDue(uint32_t now)
{
  const bool tokenExpired = !idToken.isEmpty() &&
                            now - lastAuthenticationAt >= TOKEN_REAUTH_INTERVAL_MS;
  const bool retryReady = idToken.isEmpty() &&
                          (!authenticationAttempted ||
                           now - lastAuthenticationAttemptAt >= AUTH_RETRY_INTERVAL_MS);
  if (!tokenExpired && !retryReady)
    return;

  authenticationAttempted = true;
  lastAuthenticationAttemptAt = now;
  if (!authenticate())
    idToken = "";
}

bool putJson(const String &path, const String &jsonBody)
{
  WiFiClientSecure client;
  client.setCACert(FIREBASE_ROOT_CA);

  const String url = String(FIREBASE_DATABASE_URL) + path +
                     "?auth=" + urlEncode(idToken);
  HTTPClient http;
  if (!http.begin(client, url))
  {
    Serial.println("ERROR: Could not start Firebase database request.");
    return false;
  }

  http.addHeader("Content-Type", "application/json");
  const int statusCode = http.PUT(jsonBody);
  const String responseBody = http.getString();
  http.end();

  if (statusCode < 200 || statusCode >= 300)
  {
    Serial.printf("ERROR: Firebase PUT %s failed (HTTP %d): %s\n",
                  path.c_str(),
                  statusCode, responseBody.c_str());
    return false;
  }

  return true;
}

bool uploadReading(const String &recordId, const String &jsonBody)
{
  JsonDocument uploaded;
  const DeserializationError error = deserializeJson(uploaded, jsonBody);
  if (error)
  {
    Serial.printf("ERROR: Could not prepare uploaded reading: %s\n", error.c_str());
    return false;
  }
  uploaded["status"] = "online";
  uploaded["uploadedAt"] = time(nullptr);
  String uploadedJson;
  serializeJson(uploaded, uploadedJson);

  const String historyPath = String(DATABASE_HISTORY_PATH) + recordId + ".json";
  if (!putJson(historyPath, uploadedJson))
    return false;
  if (!putJson(DATABASE_LATEST_PATH, uploadedJson))
    return false;

  return true;
}

uint64_t readSequenceFile(const char *path)
{
  File file = SD.open(path, FILE_READ);
  if (!file)
    return 0;

  String value = file.readStringUntil('\n');
  file.close();
  return strtoull(value.c_str(), nullptr, 10);
}

uint64_t findHighestQueuedSequence()
{
  uint64_t highest = 0;
  File directory = SD.open(QUEUE_DIRECTORY);
  if (!directory || !directory.isDirectory())
  {
    if (directory)
      directory.close();
    return highest;
  }

  File entry = directory.openNextFile();
  while (entry)
  {
    if (entry.isDirectory())
    {
      String shardName = entry.name();
      const int slash = shardName.lastIndexOf('/');
      if (slash >= 0)
        shardName = shardName.substring(slash + 1);
      if (isQueueShardName(shardName))
      {
        File shard = SD.open((String(QUEUE_DIRECTORY) + "/" + shardName).c_str());
        if (shard && shard.isDirectory())
        {
          File queued = shard.openNextFile();
          while (queued)
          {
            String name = queued.name();
            const int nameSlash = name.lastIndexOf('/');
            if (nameSlash >= 0)
              name = name.substring(nameSlash + 1);
            const int separator = name.lastIndexOf('-');
            const int extension = name.lastIndexOf('.');
            if (!queued.isDirectory() && name.startsWith(DEVICE_ID) &&
                name.endsWith(".json") && separator >= 0 && extension > separator)
            {
              const uint64_t value = strtoull(
                  name.substring(separator + 1, extension).c_str(), nullptr, 10);
              if (value > highest)
                highest = value;
            }
            queued.close();
            queued = shard.openNextFile();
          }
          shard.close();
        }
      }
    }
    entry.close();
    entry = directory.openNextFile();
  }
  directory.close();
  return highest;
}

bool saveQueueSequence(uint64_t sequence)
{
  const char *sequencePath = (sequence & 1U) ? "/queue-sequence-1.txt" : "/queue-sequence-0.txt";
  SD.remove(SEQUENCE_TEMP_PATH);
  File file = SD.open(SEQUENCE_TEMP_PATH, FILE_WRITE);
  if (!file)
  {
    Serial.println("ERROR: Could not write SD queue sequence.");
    return false;
  }

  file.printf("%llu\n", static_cast<unsigned long long>(sequence));
  file.flush();
  const bool written = file.getWriteError() == 0;
  file.close();
  if (!written)
  {
    SD.remove(SEQUENCE_TEMP_PATH);
    Serial.println("ERROR: SD queue sequence write was incomplete.");
    return false;
  }

  SD.remove(sequencePath);
  if (!SD.rename(SEQUENCE_TEMP_PATH, sequencePath))
  {
    SD.remove(SEQUENCE_TEMP_PATH);
    Serial.println("ERROR: Could not commit SD queue sequence.");
    return false;
  }
  return true;
}

String makeRecordId(uint64_t sequence)
{
  char suffix[24];
  snprintf(suffix, sizeof(suffix), "%012llu",
           static_cast<unsigned long long>(sequence));
  return String(DEVICE_ID) + "-" + suffix;
}

String queueShardPath(uint64_t sequence)
{
  char shard[16];
  snprintf(shard, sizeof(shard), "%08llu",
           static_cast<unsigned long long>(sequence / 1000ULL));
  return String(QUEUE_DIRECTORY) + "/" + shard;
}

bool isQueueShardName(const String &name)
{
  if (name.length() != 8)
    return false;
  for (uint8_t i = 0; i < name.length(); ++i)
  {
    if (name[i] < '0' || name[i] > '9')
      return false;
  }
  return true;
}

bool queueShardHasRecords(const String &shardName)
{
  const String shardPath = String(QUEUE_DIRECTORY) + "/" + shardName;
  File shard = SD.open(shardPath.c_str());
  if (!shard || !shard.isDirectory())
  {
    if (shard)
      shard.close();
    return false;
  }

  bool hasRecords = false;
  File entry = shard.openNextFile();
  while (entry)
  {
    String name = entry.name();
    const int slash = name.lastIndexOf('/');
    if (slash >= 0)
      name = name.substring(slash + 1);
    if (!entry.isDirectory() && name.endsWith(".json"))
      hasRecords = true;
    entry.close();
    if (hasRecords)
      break;
    entry = shard.openNextFile();
  }
  shard.close();
  return hasRecords;
}

bool makeReadingJson(String &recordId, String &jsonBody,
                     float ph, float turbidityNtu, float temperatureC,
                     float tdsPpm, float dissolvedOxygenMgL)
{
  if (sdReady)
  {
    if (queueSequence == UINT64_MAX)
    {
      Serial.println("ERROR: SD queue sequence is exhausted.");
      return false;
    }

    const uint64_t nextSequence = queueSequence + 1;
    if (!saveQueueSequence(nextSequence))
      return false;
    queueSequence = nextSequence;
    recordId = makeRecordId(queueSequence);
  }
  else
  {
    recordId = String(DEVICE_ID) + "-live-" + String(millis());
    Serial.println("WARNING: SD card unavailable; this reading cannot be buffered for offline recovery.");
  }

  JsonDocument reading;
  reading["recordId"] = recordId;
  reading["deviceId"] = DEVICE_ID;
  reading["ph"] = ph;
  reading["turbidity"] = turbidityNtu;
  reading["temperature"] = temperatureC;
  reading["tds"] = tdsPpm;
  reading["dissolvedOxygen"] = dissolvedOxygenMgL;
  reading["status"] = WiFi.status() == WL_CONNECTED ? "queued" : "offline-buffered";
  reading["remarks"] = "Sensor reading";
  const time_t timestamp = time(nullptr);
  reading["timestamp"] = timestamp > 1700000000 ? static_cast<int64_t>(timestamp) : 0;

  jsonBody = "";
  serializeJson(reading, jsonBody);
  return true;
}

bool enqueueReading(const String &recordId, const String &jsonBody)
{
  SD.remove(QUEUE_TEMP_PATH);
  File file = SD.open(QUEUE_TEMP_PATH, FILE_WRITE);
  if (!file)
  {
    Serial.println("ERROR: Could not create a temporary SD queue record.");
    return false;
  }

  const size_t written = file.print(jsonBody);
  file.flush();
  const bool complete = written == jsonBody.length() && file.getWriteError() == 0;
  file.close();
  if (!complete)
  {
    SD.remove(QUEUE_TEMP_PATH);
    Serial.println("ERROR: SD queue record write was incomplete.");
    return false;
  }

  const int separator = recordId.lastIndexOf('-');
  if (separator < 0)
  {
    SD.remove(QUEUE_TEMP_PATH);
    Serial.println("ERROR: Invalid SD queue record identifier.");
    return false;
  }
  const uint64_t sequence = strtoull(recordId.substring(separator + 1).c_str(),
                                     nullptr, 10);
  const String shardPath = queueShardPath(sequence);
  if (!SD.exists(shardPath.c_str()) && !SD.mkdir(shardPath.c_str()))
  {
    SD.remove(QUEUE_TEMP_PATH);
    Serial.printf("ERROR: Could not create SD queue shard %s.\n", shardPath.c_str());
    return false;
  }

  const String finalPath = shardPath + "/" + recordId + ".json";
  if (SD.exists(finalPath.c_str()) ||
      !SD.rename(QUEUE_TEMP_PATH, finalPath.c_str()))
  {
    SD.remove(QUEUE_TEMP_PATH);
    Serial.printf("ERROR: Could not commit SD queue record %s.\n", recordId.c_str());
    return false;
  }

  Serial.printf("Saved reading %s to SD card.\n", recordId.c_str());
  return true;
}

bool findOldestQueuedReading(String &path, String &recordId, String &jsonBody)
{
  File directory = SD.open(QUEUE_DIRECTORY);
  if (!directory || !directory.isDirectory())
  {
    if (directory)
      directory.close();
    Serial.println("ERROR: SD queue directory is unavailable.");
    return false;
  }

  String oldestShard;
  File entry = directory.openNextFile();
  while (entry)
  {
    if (entry.isDirectory())
    {
      String name = entry.name();
      const int slash = name.lastIndexOf('/');
      if (slash >= 0)
        name = name.substring(slash + 1);

      if (isQueueShardName(name) && queueShardHasRecords(name) &&
          (oldestShard.isEmpty() || name < oldestShard))
        oldestShard = name;
    }
    entry.close();
    entry = directory.openNextFile();
  }
  directory.close();

  if (oldestShard.isEmpty())
    return false;

  const String shardPath = String(QUEUE_DIRECTORY) + "/" + oldestShard;
  File shard = SD.open(shardPath.c_str());
  if (!shard || !shard.isDirectory())
  {
    if (shard)
      shard.close();
    Serial.printf("ERROR: Could not open SD queue shard %s.\n", shardPath.c_str());
    return false;
  }

  String oldestName;
  entry = shard.openNextFile();
  while (entry)
  {
    if (!entry.isDirectory())
    {
      String name = entry.name();
      const int slash = name.lastIndexOf('/');
      if (slash >= 0)
        name = name.substring(slash + 1);
      if (name.endsWith(".json") && (oldestName.isEmpty() || name < oldestName))
        oldestName = name;
    }
    entry.close();
    entry = shard.openNextFile();
  }
  shard.close();
  if (oldestName.isEmpty())
  {
    if (!SD.rmdir(shardPath.c_str()))
      Serial.printf("WARNING: Could not remove empty SD queue shard %s.\n",
                    shardPath.c_str());
    return false;
  }

  path = shardPath + "/" + oldestName;
  recordId = oldestName.substring(0, oldestName.length() - 5);
  File queued = SD.open(path.c_str(), FILE_READ);
  if (!queued)
  {
    Serial.printf("ERROR: Could not read SD queue record %s.\n", path.c_str());
    return false;
  }

  jsonBody = queued.readString();
  queued.close();
  if (jsonBody.isEmpty())
  {
    Serial.printf("ERROR: SD queue record %s is empty; it was retained.\n", path.c_str());
    return false;
  }
  return true;
}

void flushQueuedReadings()
{
  for (uint8_t uploaded = 0; uploaded < MAX_BACKLOG_UPLOADS_PER_LOOP; ++uploaded)
  {
    String path;
    String recordId;
    String jsonBody;
    if (!findOldestQueuedReading(path, recordId, jsonBody))
      return;

    if (!uploadReading(recordId, jsonBody))
    {
      idToken = "";
      Serial.printf("Upload paused; queued record %s remains on SD.\n", recordId.c_str());
      return;
    }

    if (!SD.remove(path))
    {
      Serial.printf("ERROR: Uploaded record %s but could not remove its SD copy; it will be retried safely.\n",
                    recordId.c_str());
      return;
    }
    const int separator = path.lastIndexOf('/');
    if (separator > 0)
    {
      const String shardPath = path.substring(0, separator);
      if (!queueShardHasRecords(shardPath.substring(shardPath.lastIndexOf('/') + 1)))
      {
        if (!SD.rmdir(shardPath.c_str()))
          Serial.printf("WARNING: Could not remove empty SD queue shard %s.\n",
                        shardPath.c_str());
      }
    }
    Serial.printf("Uploaded queued reading %s; removed it from SD.\n", recordId.c_str());
  }
}

bool secretsConfigured()
{
  return strlen(WIFI_SSID) > 0 &&
         strlen(FIREBASE_API_KEY) > 0 &&
         strlen(FIREBASE_USER_EMAIL) > 0 &&
         strlen(FIREBASE_USER_PASSWORD) > 0 &&
         strlen(FIREBASE_DATABASE_URL) > 0 &&
         strlen(FIREBASE_ROOT_CA) > 0 &&
         String(WIFI_SSID) != "YOUR_WIFI_NAME" &&
         String(FIREBASE_API_KEY) != "YOUR_FIREBASE_WEB_API_KEY" &&
         String(FIREBASE_USER_EMAIL) != "YOUR_FIREBASE_USER_EMAIL" &&
         String(FIREBASE_USER_PASSWORD) != "YOUR_FIREBASE_USER_PASSWORD" &&
         String(FIREBASE_DATABASE_URL).indexOf("YOUR_PROJECT") < 0 &&
         String(FIREBASE_ROOT_CA).indexOf("PASTE_GOOGLE_TRUST_SERVICES") < 0;
}
} // namespace

void setup()
{
  Serial.begin(115200);
  analogReadResolution(12);
  analogSetPinAttenuation(PH_PIN, ADC_11db);
  analogSetPinAttenuation(TURBIDITY_PIN, ADC_11db);
  analogSetPinAttenuation(TDS_PIN, ADC_11db);
  analogSetPinAttenuation(DISSOLVED_OXYGEN_PIN, ADC_11db);
  temperatureSensor.begin();

  if (SD.begin(SD_CS_PIN))
  {
    sdReady = true;
    if (!SD.exists(QUEUE_DIRECTORY) && !SD.mkdir(QUEUE_DIRECTORY))
    {
      sdReady = false;
      Serial.println("ERROR: Could not create the SD queue directory; offline buffering is disabled.");
    }
    else
    {
      const uint64_t savedSequence = max(readSequenceFile("/queue-sequence-0.txt"),
                                         readSequenceFile("/queue-sequence-1.txt"));
      const uint64_t queuedSequence = findHighestQueuedSequence();
      queueSequence = savedSequence > queuedSequence ? savedSequence : queuedSequence;
      if (SD.exists(QUEUE_TEMP_PATH))
      {
        SD.remove(QUEUE_TEMP_PATH);
        Serial.println("WARNING: Removed an incomplete temporary queue file from the previous run.");
      }
      Serial.printf("SD card ready. Queue sequence: %llu\n",
                    static_cast<unsigned long long>(queueSequence));
    }
  }
  else
  {
    Serial.println("ERROR: SD card initialization failed. Live upload can continue when online, but offline readings cannot be saved.");
  }

  if (!secretsConfigured())
  {
    Serial.println("ERROR: Configure ESP32/secrets.h using secrets.example.h first.");
    while (true)
      delay(1000);
  }

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  lastWifiRetryAt = millis();
  Serial.println("Connecting to Wi-Fi in the background; sensor sampling will continue offline.");
}

void loop()
{
  const uint32_t now = millis();
  const bool wifiConnected = WiFi.status() == WL_CONNECTED;

  if (!wifiConnected)
  {
    idToken = "";
    if (wasWifiConnected)
      Serial.println("Wi-Fi disconnected. Sensor readings will be buffered on the SD card.");
    if (now - lastWifiRetryAt >= WIFI_RETRY_INTERVAL_MS)
    {
      lastWifiRetryAt = now;
      WiFi.reconnect();
      Serial.println("Retrying Wi-Fi connection...");
    }
  }
  else if (!wasWifiConnected)
  {
    Serial.printf("Wi-Fi connected: %s\n", WiFi.localIP().toString().c_str());
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
  }
  wasWifiConnected = wifiConnected;

  if (!wifiConnected)
  {
    networkTimeReady = false;
  }
  else
  {
    networkTimeReady = time(nullptr) > 1700000000;
    if (networkTimeReady)
      lastTimeWarningAt = 0;
    else if (now - lastTimeWarningAt >= 10000)
    {
      lastTimeWarningAt = now;
      Serial.println("Waiting for network time before secure Firebase requests; readings continue to be buffered.");
    }

    if (networkTimeReady)
      authenticateIfDue(now);
  }

  if (now - lastSampleAt >= SAMPLE_INTERVAL_MS)
  {
    lastSampleAt = now;
    temperatureSensor.requestTemperatures();
    const float temperatureC = temperatureSensor.getTempCByIndex(0);
    if (temperatureC == DEVICE_DISCONNECTED_C)
    {
      Serial.println("ERROR: DS18B20 not detected; check its wiring. This sample was skipped.");
    }
    else
    {
      const float ph = readPh(readVoltage(PH_PIN));
      const float turbidityNtu = readTurbidityNtu(readVoltage(TURBIDITY_PIN));
      const float tdsPpm = readTdsPpm(readVoltage(TDS_PIN), temperatureC);
      const float dissolvedOxygenMgL = readDissolvedOxygen(readVoltage(DISSOLVED_OXYGEN_PIN));

      String recordId;
      String jsonBody;
      if (makeReadingJson(recordId, jsonBody, ph, turbidityNtu, temperatureC,
                          tdsPpm, dissolvedOxygenMgL))
      {
        if (sdReady)
        {
          if (!enqueueReading(recordId, jsonBody))
          {
            Serial.printf("ERROR: Reading %s was not buffered on SD.\n", recordId.c_str());
            if (wifiConnected && networkTimeReady && !idToken.isEmpty())
              uploadReading(recordId, jsonBody);
          }
        }
        else if (wifiConnected && networkTimeReady && !idToken.isEmpty())
        {
          if (!uploadReading(recordId, jsonBody))
            idToken = "";
        }
        else
        {
          Serial.println("ERROR: Reading cannot be buffered because the SD card is unavailable; it will not be recoverable.");
        }
      }
    }
  }

  if (wifiConnected && networkTimeReady && sdReady && !idToken.isEmpty())
    flushQueuedReadings();

  delay(50);
}
