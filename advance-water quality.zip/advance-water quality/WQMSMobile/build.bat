@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle was not found. Open this folder in Android Studio and sync the project.
  exit /b 1
)
call gradle assembleDebug
if errorlevel 1 exit /b %errorlevel%
echo APK created at app\build\outputs\apk\debug\app-debug.apk
