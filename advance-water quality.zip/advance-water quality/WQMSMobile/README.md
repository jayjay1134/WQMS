# WQMS Mobile for Android

Native Android dashboard for the ESP32 firmware in `../ESP32/ESP32.ino`.
It signs in with Firebase Authentication and polls `/sensorData/latest` every
five seconds. Login credentials are kept in memory only; the database URL,
Firebase Web API key, and email are saved locally for convenience. The Firebase
refresh token is encrypted with Android Keystore so the app can restore your
session after closing or restarting.

## Build an APK

1. Install Android Studio with the Android SDK Platform 35 and JDK 17.
2. Open the `WQMSMobile` folder in Android Studio and allow Gradle sync to finish.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio creates the debug APK at
   `app/build/outputs/apk/debug/app-debug.apk`. For sharing beyond testing,
   create a signed release APK using **Build > Generate Signed Bundle / APK**.

The Android SDK/JDK/Gradle are not present in the source workspace, so the APK
must be built on a machine with Android Studio or the Android command-line tools.

## Connect to Firebase

The app is prefilled with the Realtime Database URL and Web API key from the
WQMS Firebase web configuration. Enter the email and password of a Firebase
Authentication user. Enable Email/Password sign-in in Firebase. Configure the
Realtime Database rules to allow that authenticated user to read
`/sensorData/latest`; do not enable public database access. The API key is
project configuration, not a database password.

The sign-in screen prioritizes the Firebase email and password fields. Tap
**Firebase project settings** to expand the database URL and Web API key fields
if you need to connect to a different Firebase project. The branded welcome
panel, water-drop illustration, clear sign-in action, and compact security note
are designed to keep login focused on the account credentials.

If sign-in fails, the app keeps the entered values on the login screen and shows
the Firebase error there. The password is kept only in the active form and
never saved to preferences. During an active session, the app refreshes Firebase
ID tokens using the Firebase refresh-token endpoint instead of forcing a
periodic logout. Use **Log out** in the dashboard when you want to end the
saved session on this device. Temporary network or Firebase errors keep the
session and trigger a retry; a revoked or invalid refresh token requires signing
in again.

The mobile app expects the ESP32's JSON field names: `ph`, `turbidity`,
`temperature`, `tds`, `dissolvedOxygen`, `deviceId`, `status`, `remarks`, and
`timestamp`. The timestamp is displayed as supplied by the firmware.

## Dashboard sections

The mobile interface uses a compact dark theme with a branded Firebase sign-in
screen, sensor cards, connection status, and bottom navigation for Dashboard,
Sensor Data, Alerts, Reports, and Thresholds. Configure optional
minimum/maximum alert values in Thresholds; the app does not assume water-safety
limits. Reports can share a CSV of the latest reading. The current ESP32
firmware overwrites `/sensorData/latest`; historical reports require a
separate history-writing change to the firmware and database structure.

## Source layout

- `app/src/main/java/com/wqms/mobile/MainActivity.java`: mobile UI and Firebase
  Authentication/Realtime Database HTTPS requests.
- `app/src/main/AndroidManifest.xml`: Internet permission and application entry
  point.
