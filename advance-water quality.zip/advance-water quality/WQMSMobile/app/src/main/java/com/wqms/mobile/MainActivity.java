package com.wqms.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.util.Base64;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int BACKGROUND = Color.rgb(8, 17, 31);
    private static final int PANEL = Color.rgb(17, 29, 47);
    private static final int BORDER = Color.rgb(37, 54, 75);
    private static final int MUTED = Color.rgb(151, 171, 198);
    private static final int WHITE = Color.rgb(238, 244, 251);
    private static final int ACCENT = Color.rgb(56, 189, 248);
    private static final int GREEN = Color.rgb(52, 211, 153);
    private static final int[] SENSOR_COLORS = {
            Color.rgb(56, 189, 248), Color.rgb(45, 212, 191),
            Color.rgb(251, 191, 36), Color.rgb(129, 140, 248),
            Color.rgb(52, 211, 153)
    };
    private static final long REFRESH_INTERVAL_MS = 5000L;
    private static final String PREFERENCES = "wqms_mobile";
    private static final String DEFAULT_DATABASE_URL =
            "https://water-monitoring-b46f4-default-rtdb.firebaseio.com";
    private static final String DEFAULT_API_KEY =
            "AIzaSyDUfgCEO-ZVW_eudMRDvUD4D0p-Kc3uQeg";
    private static final String[] SECTION_NAMES = {
            "Dashboard", "Sensor Data", "Alerts", "Reports", "Thresholds"
    };
    private static final String[] SENSOR_KEYS = {
            "ph", "turbidity", "temperature", "tds", "dissolvedOxygen"
    };
    private static final String[] SENSOR_NAMES = {
            "pH Level", "Turbidity", "Temperature", "TDS", "Dissolved Oxygen"
    };
    private static final String[] SENSOR_UNITS = {
            "", "NTU", "°C", "ppm", "mg/L"
    };
    private static final int[] SENSOR_DECIMALS = {2, 1, 2, 1, 2};
    private static final long TOKEN_REFRESH_BUFFER_MS = 2L * 60L * 1000L;
    private static final String SESSION_KEY_ALIAS = "wqms_firebase_refresh_token";
    private static final String REFRESH_TOKEN_CIPHERTEXT = "refreshTokenCiphertext";
    private static final String REFRESH_TOKEN_IV = "refreshTokenIv";

    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Object sessionLock = new Object();
    private final Runnable refreshTask = new Runnable() {
        @Override
        public void run() {
            if (isFinishing() || databaseUrl == null) {
                return;
            }
            if (idToken == null) {
                if (refreshToken != null && !authenticationRefreshInFlight) {
                    refreshAuthentication();
                }
                handler.postDelayed(this, REFRESH_INTERVAL_MS);
                return;
            }
            if (SystemClock.elapsedRealtime() >= tokenExpiresAtElapsed - TOKEN_REFRESH_BUFFER_MS) {
                refreshAuthentication();
                return;
            }
            fetchReading();
            handler.postDelayed(this, REFRESH_INTERVAL_MS);
        }
    };

    private String databaseUrl;
    private String idToken;
    private String refreshToken;
    private long tokenExpiresAtElapsed;
    private boolean requestInFlight;
    private boolean authenticationRefreshInFlight;
    private volatile long sessionGeneration;
    private LinearLayout root;
    private TextView status;
    private TextView[] values;
    private TextView latestDetails;
    private ScrollView pageScroll;
    private LinearLayout pageContent;
    private JSONObject latestReading;
    private int currentSection;
    private Button[] navigationButtons;
    private TextView connectionError;
    private EditText databaseInput;
    private EditText apiKeyInput;
    private EditText emailInput;
    private EditText passwordInput;
    private Button signInButton;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        restoreSession();
    }

    private void restoreSession() {
        android.content.SharedPreferences preferences =
                getSharedPreferences(PREFERENCES, MODE_PRIVATE);
        String savedDatabaseUrl = preferences.getString("databaseUrl", DEFAULT_DATABASE_URL);
        String savedApiKey = preferences.getString("apiKey", DEFAULT_API_KEY);
        String savedEmail = preferences.getString("email", "");
        try {
            String savedRefreshToken = decryptRefreshToken(
                    preferences.getString(REFRESH_TOKEN_CIPHERTEXT, null),
                    preferences.getString(REFRESH_TOKEN_IV, null));
            if (savedRefreshToken == null || !isFirebaseDatabaseUrl(savedDatabaseUrl) ||
                    savedApiKey.isEmpty()) {
                showLogin(null, savedDatabaseUrl, savedApiKey, savedEmail, null);
                return;
            }

            databaseUrl = savedDatabaseUrl;
            refreshToken = savedRefreshToken;
            showDashboard();
            setStatus("CONNECTING", GREEN, Color.rgb(12, 47, 43),
                    Color.rgb(26, 102, 82));
            refreshAuthentication();
            handler.postDelayed(refreshTask, REFRESH_INTERVAL_MS);
        } catch (Exception exception) {
            boolean cleared = clearPersistedSession();
            showLogin("Your saved Firebase session could not be restored. " +
                            (cleared ? "Please sign in again." :
                                    "Stored session cleanup failed; sign in again and retry."),
                    savedDatabaseUrl, savedApiKey, savedEmail, null);
        }
    }

    private boolean isFirebaseDatabaseUrl(String value) {
        try {
            java.net.URI uri = new java.net.URI(value);
            String host = uri.getHost();
            if (host == null || uri.getUserInfo() != null ||
                    uri.getQuery() != null || uri.getFragment() != null) {
                return false;
            }
            host = host.toLowerCase(java.util.Locale.ROOT);
            return uri.getScheme() != null &&
                    "https".equalsIgnoreCase(uri.getScheme()) &&
                    (host.endsWith(".firebaseio.com") ||
                            host.endsWith(".firebasedatabase.app")) &&
                    !host.contains("YOUR_PROJECT");
        } catch (java.net.URISyntaxException exception) {
            return false;
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(refreshTask);
        network.shutdownNow();
        super.onDestroy();
    }

    private void showLogin(String notice) {
        showLogin(notice, null, null, null, null);
    }

    private void showLogin(String notice, String databaseDraft, String apiKeyDraft,
                           String emailDraft, String passwordDraft) {
        handler.removeCallbacks(refreshTask);
        databaseUrl = null;
        idToken = null;
        refreshToken = null;
        tokenExpiresAtElapsed = 0;
        authenticationRefreshInFlight = false;
        requestInFlight = false;
        signInButton = null;
        root = createRoot();

        ScrollView loginScroll = new ScrollView(this);
        loginScroll.setFillViewport(true);
        loginScroll.setClipToPadding(false);
        LinearLayout loginContent = new LinearLayout(this);
        loginContent.setOrientation(LinearLayout.VERTICAL);
        loginContent.setPadding(dp(22), dp(24), dp(22), dp(28));
        loginScroll.addView(loginContent, new ScrollView.LayoutParams(-1, -2));

        LinearLayout heroCard = new LinearLayout(this);
        heroCard.setGravity(Gravity.CENTER_VERTICAL);
        heroCard.setOrientation(LinearLayout.HORIZONTAL);
        heroCard.setPadding(dp(17), dp(18), dp(13), dp(18));
        heroCard.setBackground(gradientShape(
                new int[] {Color.rgb(14, 57, 79), Color.rgb(13, 34, 57)},
                Color.rgb(32, 91, 116), 24));
        heroCard.setElevation(dp(3));

        LinearLayout heroCopy = new LinearLayout(this);
        heroCopy.setOrientation(LinearLayout.VERTICAL);
        TextView logo = text("WQ", 15, Color.rgb(5, 26, 43), true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(shape(ACCENT, ACCENT, 13));
        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        brandRow.addView(logo, new LinearLayout.LayoutParams(dp(38), dp(38)));
        LinearLayout brandName = new LinearLayout(this);
        brandName.setOrientation(LinearLayout.VERTICAL);
        brandName.addView(text("WQMS", 17, WHITE, true),
                params(-1, -2, 0, 0, 0, 1));
        TextView brandSubtitle = text("WATER QUALITY MONITORING", 9, MUTED, true);
        brandSubtitle.setLetterSpacing(0.06f);
        brandName.addView(brandSubtitle, params(-1, -2, 0, 1, 0, 0));
        brandRow.addView(brandName, params(-2, -2, 9, 0, 0, 0));
        heroCopy.addView(brandRow, params(-1, -2, 0, 0, 0, 19));
        TextView eyebrow = text("SMART WATER INSIGHTS", 9, GREEN, true);
        eyebrow.setLetterSpacing(0.12f);
        heroCopy.addView(eyebrow, params(-1, -2, 0, 0, 0, 7));
        TextView headline = text("Know your water.\nTrust every reading.", 20, WHITE, true);
        headline.setLineSpacing(dp(2), 1f);
        heroCopy.addView(headline, params(-1, -2, 0, 0, 0, 7));
        TextView heroDescription = text("Live monitoring, made simple.", 12, MUTED, false);
        heroCopy.addView(heroDescription, params(-1, -2, 0, 0, 0, 0));
        heroCard.addView(heroCopy, new LinearLayout.LayoutParams(0, -2, 1f));

        WatermarkView waterMark = new WatermarkView();
        heroCard.addView(waterMark, params(78, 92, 4, 0, 0, 0));
        loginContent.addView(heroCard, params(-1, -2, 0, 0, 0, 25));

        TextView secureBadge = text("SECURE", 9, GREEN, true);
        secureBadge.setGravity(Gravity.CENTER);
        secureBadge.setPadding(dp(10), dp(7), dp(10), dp(7));
        secureBadge.setBackground(shape(Color.rgb(13, 48, 46), Color.rgb(30, 91, 77), 20));

        LinearLayout form = panel();
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(19), dp(18), dp(18));
        form.setBackground(shape(Color.rgb(14, 26, 43), Color.rgb(39, 57, 80), 22));
        LinearLayout formHeading = new LinearLayout(this);
        formHeading.setGravity(Gravity.CENTER_VERTICAL);
        formHeading.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout headingCopy = new LinearLayout(this);
        headingCopy.setOrientation(LinearLayout.VERTICAL);
        headingCopy.addView(text("Welcome back", 20, WHITE, true),
                params(-1, -2, 0, 0, 0, 3));
        headingCopy.addView(text("Sign in to open your dashboard.", 13, MUTED, false),
                params(-1, -2, 0, 0, 0, 0));
        formHeading.addView(headingCopy, new LinearLayout.LayoutParams(0, -2, 1f));
        formHeading.addView(secureBadge, params(-2, -2, 8, 0, 0, 0));
        form.addView(formHeading, params(-1, -2, 0, 0, 0, 17));
        if (notice != null) {
            TextView message = text(notice, 14, Color.rgb(255, 197, 207), false);
            message.setBackground(shape(Color.rgb(57, 31, 42), Color.rgb(132, 66, 80), 13));
            message.setPadding(dp(13), dp(12), dp(13), dp(12));
            form.addView(message, params(-1, -2, 0, 0, 0, 14));
        }
        addField(form, "Email address", "name@example.com", false);
        emailInput = lastInput(form);
        addField(form, "Password", "Enter your password", true);
        passwordInput = lastInput(form);

        LinearLayout projectSettings = new LinearLayout(this);
        projectSettings.setOrientation(LinearLayout.VERTICAL);
        projectSettings.setBackground(shape(Color.rgb(10, 20, 35), Color.rgb(34, 50, 71), 15));
        projectSettings.setPadding(dp(12), dp(12), dp(12), dp(2));
        TextView projectSettingsToggle = text("Firebase project settings     +",
                13, ACCENT, true);
        projectSettingsToggle.setGravity(Gravity.CENTER_VERTICAL);
        projectSettingsToggle.setMinHeight(dp(38));
        projectSettingsToggle.setContentDescription("Show Firebase project settings");
        projectSettings.addView(projectSettingsToggle, params(-1, -2, 0, 0, 0, 8));
        addField(projectSettings, "Realtime Database URL", DEFAULT_DATABASE_URL, false);
        databaseInput = lastInput(projectSettings);
        addField(projectSettings, "Web API key", "Firebase project Web API key", false);
        apiKeyInput = lastInput(projectSettings);
        projectSettings.setVisibility(View.GONE);
        projectSettingsToggle.setOnClickListener(v -> {
            boolean expanded = projectSettings.getVisibility() != View.VISIBLE;
            projectSettings.setVisibility(expanded ? View.VISIBLE : View.GONE);
            projectSettingsToggle.setText(expanded
                    ? "Firebase project settings     −"
                    : "Firebase project settings     +");
            projectSettingsToggle.setContentDescription(expanded
                    ? "Hide Firebase project settings"
                    : "Show Firebase project settings");
        });
        form.addView(projectSettings, params(-1, -2, 0, 1, 0, 14));

        if (databaseDraft != null) databaseInput.setText(databaseDraft);
        if (apiKeyDraft != null) apiKeyInput.setText(apiKeyDraft);
        if (emailDraft != null) emailInput.setText(emailDraft);
        if (passwordDraft != null) passwordInput.setText(passwordDraft);
        signInButton = button("Sign in to dashboard");
        signInButton.setTextSize(16);
        signInButton.setBackground(shape(Color.rgb(14, 112, 151),
                Color.rgb(53, 177, 214), 15));
        signInButton.setElevation(dp(3));
        signInButton.setOnClickListener(v -> signIn());
        form.addView(signInButton, params(-1, 54, 0, 0, 0, 0));
        loginContent.addView(form, params(-1, -2, 0, 0, 0, 17));

        TextView privacy = text("Your password is only used to sign in and is never saved on this phone.",
                12, MUTED, false);
        privacy.setGravity(Gravity.CENTER);
        privacy.setLineSpacing(dp(2), 1f);
        loginContent.addView(privacy, params(-1, -2, 8, 0, 8, 10));
        TextView footer = text("Protected by Firebase Authentication", 11,
                Color.rgb(104, 127, 153), false);
        footer.setGravity(Gravity.CENTER);
        loginContent.addView(footer, params(-1, -2, 0, 2, 0, 0));
        setContentView(loginScroll);
    }

    private void signIn() {
        final String enteredDatabaseUrl = databaseInput.getText().toString().trim();
        final String enteredApiKey = apiKeyInput.getText().toString().trim();
        final String enteredEmail = emailInput.getText().toString().trim();
        final String enteredPassword = passwordInput.getText().toString();

        if (!isFirebaseDatabaseUrl(enteredDatabaseUrl) ||
                enteredApiKey.isEmpty() ||
                enteredEmail.isEmpty() ||
                enteredPassword.isEmpty()) {
            showLogin("Check the database URL, API key, email, and password, then try again.",
                    enteredDatabaseUrl, enteredApiKey, enteredEmail, enteredPassword);
            return;
        }

        getSharedPreferences(PREFERENCES, MODE_PRIVATE).edit()
                .putString("databaseUrl", enteredDatabaseUrl.replaceAll("/+$", ""))
                .putString("apiKey", enteredApiKey)
                .putString("email", enteredEmail)
                .apply();

        final String normalizedUrl = enteredDatabaseUrl.replaceAll("/+$", "");
        final Button connect = signInButton;
        if (connect == null) {
            throw new IllegalStateException("Sign-in button is missing.");
        }
        connect.setEnabled(false);
        connect.setText("Connecting...");
        final long signInGeneration = ++sessionGeneration;

        network.execute(() -> {
            try {
                String endpoint = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" +
                        java.net.URLEncoder.encode(enteredApiKey, "UTF-8");
                JSONObject credentials = new JSONObject();
                credentials.put("email", enteredEmail);
                credentials.put("password", enteredPassword);
                credentials.put("returnSecureToken", true);
                JSONObject response = new JSONObject(request(endpoint, "POST", credentials.toString()));
                final String token = response.getString("idToken");
                final String signedInRefreshToken = response.getString("refreshToken");
                final long expiresInSeconds = parseExpiresIn(response.optString("expiresIn", ""));
                if (sessionGeneration != signInGeneration) {
                    return;
                }
                if (!persistRefreshToken(signedInRefreshToken, signInGeneration)) {
                    return;
                }

                handler.post(() -> {
                    if (isFinishing() || sessionGeneration != signInGeneration) {
                        return;
                    }
                    databaseUrl = normalizedUrl;
                    idToken = token;
                    refreshToken = signedInRefreshToken;
                    tokenExpiresAtElapsed = SystemClock.elapsedRealtime() +
                            expiresInSeconds * 1000L;
                    getSharedPreferences(PREFERENCES, MODE_PRIVATE).edit()
                            .putString("databaseUrl", normalizedUrl)
                            .putString("apiKey", enteredApiKey)
                            .putString("email", enteredEmail)
                            .apply();
                    showDashboard();
                    handler.post(refreshTask);
                });
            } catch (Exception exception) {
                String message = friendlyError(exception);
                handler.post(() -> {
                    if (!isFinishing()) {
                        showLogin(message, normalizedUrl, enteredApiKey,
                                enteredEmail, enteredPassword);
                    }
                });
            }
        });
    }

    private void refreshAuthentication() {
        if (authenticationRefreshInFlight || refreshToken == null || databaseUrl == null) {
            return;
        }
        authenticationRefreshInFlight = true;
        final String tokenToRefresh = refreshToken;
        final String apiKey = getSharedPreferences(PREFERENCES, MODE_PRIVATE)
                .getString("apiKey", DEFAULT_API_KEY);
        final String email = getSharedPreferences(PREFERENCES, MODE_PRIVATE)
                .getString("email", "");
        final long refreshGeneration = sessionGeneration;

        network.execute(() -> {
            try {
                String endpoint = "https://securetoken.googleapis.com/v1/token?key=" +
                        java.net.URLEncoder.encode(apiKey, "UTF-8");
                String body = "grant_type=refresh_token&refresh_token=" +
                        java.net.URLEncoder.encode(tokenToRefresh, "UTF-8");
                JSONObject response = new JSONObject(request(endpoint, "POST", body,
                        "application/x-www-form-urlencoded"));
                String newIdToken = response.getString("id_token");
                String newRefreshToken = response.getString("refresh_token");
                long expiresInSeconds = parseExpiresIn(response.optString("expires_in", ""));
                if (sessionGeneration != refreshGeneration) {
                    return;
                }
                if (!persistRefreshToken(newRefreshToken, refreshGeneration)) {
                    return;
                }

                handler.post(() -> {
                    authenticationRefreshInFlight = false;
                    if (isFinishing() || databaseUrl == null ||
                            sessionGeneration != refreshGeneration) {
                        return;
                    }
                    idToken = newIdToken;
                    refreshToken = newRefreshToken;
                    tokenExpiresAtElapsed = SystemClock.elapsedRealtime() +
                            expiresInSeconds * 1000L;
                    fetchReading();
                    handler.removeCallbacks(refreshTask);
                    handler.postDelayed(refreshTask, REFRESH_INTERVAL_MS);
                });
            } catch (Exception exception) {
                String message = friendlyError(exception);
                handler.post(() -> {
                    authenticationRefreshInFlight = false;
                    if (!isFinishing() && databaseUrl != null &&
                            sessionGeneration == refreshGeneration) {
                        if (isInvalidRefreshToken(exception)) {
                            String oldDatabaseUrl = databaseUrl;
                            boolean cleared = clearPersistedSession();
                            showLogin("Your Firebase session has expired or was revoked. " +
                                            message + (cleared ? "" :
                                            " Local session cleanup failed; please try logging out again."),
                                    oldDatabaseUrl, apiKey, email, null);
                        } else {
                            setStatus("OFFLINE", Color.rgb(255, 170, 170),
                                    Color.rgb(63, 30, 39), Color.rgb(121, 51, 65));
                            addConnectionError("Could not refresh the Firebase session. " +
                                    "The app will retry without signing you out. " + message);
                            handler.removeCallbacks(refreshTask);
                            handler.postDelayed(refreshTask, REFRESH_INTERVAL_MS);
                        }
                    }
                });
            }
        });
    }

    private boolean isInvalidRefreshToken(Exception exception) {
        String message = exception.getMessage();
        return message != null &&
                (message.contains("INVALID_REFRESH_TOKEN") ||
                        message.contains("INVALID_GRANT") ||
                        message.contains("TOKEN_EXPIRED") ||
                        message.contains("USER_DISABLED") ||
                        message.contains("USER_NOT_FOUND"));
    }

    private boolean persistRefreshToken(String token, long expectedGeneration) throws Exception {
        synchronized (sessionLock) {
            if (sessionGeneration != expectedGeneration) {
                return false;
            }
            SecretKey key = getOrCreateSessionKey();
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encrypted = cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
            boolean saved = getSharedPreferences(PREFERENCES, MODE_PRIVATE).edit()
                    .putString(REFRESH_TOKEN_CIPHERTEXT,
                            Base64.encodeToString(encrypted, Base64.NO_WRAP))
                    .putString(REFRESH_TOKEN_IV,
                            Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
                    .commit();
            if (!saved) {
                throw new IOException("Could not save the encrypted Firebase session.");
            }
            return true;
        }
    }

    private String decryptRefreshToken(String encryptedToken, String iv) throws Exception {
        if (encryptedToken == null || iv == null) {
            return null;
        }
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (!keyStore.containsAlias(SESSION_KEY_ALIAS)) {
            return null;
        }
        SecretKey key = ((KeyStore.SecretKeyEntry) keyStore.getEntry(
                SESSION_KEY_ALIAS, null)).getSecretKey();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128,
                Base64.decode(iv, Base64.NO_WRAP)));
        byte[] decrypted = cipher.doFinal(Base64.decode(encryptedToken, Base64.NO_WRAP));
        return new String(decrypted, StandardCharsets.UTF_8);
    }

    private SecretKey getOrCreateSessionKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(SESSION_KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) keyStore.getEntry(
                    SESSION_KEY_ALIAS, null)).getSecretKey();
        }
        KeyGenerator generator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(SESSION_KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    private boolean clearPersistedSession() {
        synchronized (sessionLock) {
            return getSharedPreferences(PREFERENCES, MODE_PRIVATE).edit()
                    .remove(REFRESH_TOKEN_CIPHERTEXT)
                    .remove(REFRESH_TOKEN_IV)
                    .commit();
        }
    }

    private void logout() {
        String savedDatabaseUrl = databaseUrl;
        android.content.SharedPreferences preferences =
                getSharedPreferences(PREFERENCES, MODE_PRIVATE);
        String savedApiKey = preferences.getString("apiKey", DEFAULT_API_KEY);
        String savedEmail = preferences.getString("email", "");
        sessionGeneration++;
        boolean cleared = clearPersistedSession();
        if (!cleared) {
            new AlertDialog.Builder(this)
                    .setTitle("Could not log out")
                    .setMessage("The saved Firebase session could not be cleared. Please try again.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        idToken = null;
        refreshToken = null;
        databaseUrl = null;
        tokenExpiresAtElapsed = 0;
        authenticationRefreshInFlight = false;
        requestInFlight = false;
        latestReading = null;
        showLogin("You have signed out.", savedDatabaseUrl, savedApiKey, savedEmail, null);
    }

    private long parseExpiresIn(String value) throws JSONException {
        try {
            long seconds = Long.parseLong(value);
            if (seconds <= 0) {
                throw new NumberFormatException("expiresIn must be positive");
            }
            return seconds;
        } catch (NumberFormatException exception) {
            throw new JSONException("Firebase returned an invalid token lifetime.");
        }
    }

    private void showDashboard() {
        root = createRoot();
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BACKGROUND);
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("WQMS", 24, ACCENT, true);
        brand.addView(title, params(-1, -2, 0, 0, 0, 1));
        TextView sectionBrand = text("WATER QUALITY MONITORING", 9, MUTED, true);
        sectionBrand.setLetterSpacing(0.08f);
        brand.addView(sectionBrand, params(-1, -2, 0, 0, 0, 0));
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        status = text("CONNECTING", 10, GREEN, true);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(12), dp(8), dp(12), dp(8));
        status.setBackground(shape(Color.rgb(12, 47, 43), Color.rgb(26, 102, 82), 24));
        header.addView(status, params(-2, -2, 0, 0, 0, 0));
        Button logout = button("Log out");
        logout.setTextSize(11);
        logout.setPadding(dp(10), 0, dp(10), 0);
        logout.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Log out?")
                .setMessage("You will need to sign in again to view your Firebase data.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Log out", (dialog, which) -> logout())
                .show());
        header.addView(logout, params(-2, dp(40), 8, 0, 0, 0));
        root.addView(header, params(-1, -2, 20, 16, 20, 5));

        TextView subtitle = text("Live readings from your ESP32 sensor", 13, MUTED, false);
        root.addView(subtitle, params(-1, -2, 20, 1, 20, 8));

        pageScroll = new ScrollView(this);
        pageContent = new LinearLayout(this);
        pageContent.setOrientation(LinearLayout.VERTICAL);
        pageContent.setPadding(dp(20), dp(6), dp(20), dp(12));
        pageScroll.addView(pageContent, new ScrollView.LayoutParams(-1, -2));
        root.addView(pageScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout navigation = new LinearLayout(this);
        navigation.setOrientation(LinearLayout.HORIZONTAL);
        navigation.setBackground(shape(Color.rgb(12, 22, 38), BORDER, 18));
        navigation.setElevation(dp(8));
        navigation.setPadding(dp(4), dp(5), dp(4), dp(5));
        navigationButtons = new Button[SECTION_NAMES.length];
        for (int i = 0; i < SECTION_NAMES.length; i++) {
            final int section = i;
            Button item = new Button(this);
            item.setText(SECTION_NAMES[i]);
            item.setTextSize(9);
            item.setAllCaps(false);
            item.setMinWidth(0);
            item.setMinimumWidth(0);
            item.setPadding(0, 0, 0, 0);
            item.setTextColor(i == currentSection ? ACCENT : MUTED);
            item.setBackground(i == currentSection
                    ? shape(Color.rgb(18, 55, 78), Color.rgb(18, 55, 78), 13)
                    : shape(Color.TRANSPARENT, Color.TRANSPARENT, 13));
            item.setMinHeight(0);
            navigationButtons[i] = item;
            item.setOnClickListener(v -> showSection(section));
            navigation.addView(item, new LinearLayout.LayoutParams(0, dp(46), 1));
        }
        root.addView(navigation, params(-1, -2, 10, 0, 10, 8));
        setContentView(root);
        showSection(currentSection);
    }

    private void showSection(int section) {
        int scrollPosition = pageScroll == null ? 0 : pageScroll.getScrollY();
        currentSection = section;
        connectionError = null;
        pageContent.removeAllViews();
        pageContent.addView(text(SECTION_NAMES[section], 23, WHITE, true),
                params(-1, -2, 0, 0, 0, 12));
        switch (section) {
            case 0:
                showDashboardSection();
                break;
            case 1:
                showSensorDataSection();
                break;
            case 2:
                showAlertsSection();
                break;
            case 3:
                showReportsSection();
                break;
            case 4:
                showThresholdsSection();
                break;
            default:
                throw new IllegalArgumentException("Unknown dashboard section: " + section);
        }
        updateNavigationSelection();
        if (pageScroll != null) {
            pageScroll.post(() -> pageScroll.scrollTo(0, scrollPosition));
        }
    }

    private void showDashboardSection() {
        values = new TextView[SENSOR_KEYS.length];
        for (int i = 0; i < SENSOR_KEYS.length; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.addView(metricCard(i), new LinearLayout.LayoutParams(0, dp(112), 1));
            if (i + 1 < SENSOR_KEYS.length) {
                row.addView(new View(this), new LinearLayout.LayoutParams(dp(10), 1));
                row.addView(metricCard(i + 1), new LinearLayout.LayoutParams(0, dp(112), 1));
            } else {
                row.addView(new View(this), new LinearLayout.LayoutParams(dp(10), 1));
                row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
            }
            pageContent.addView(row, params(-1, dp(112), 0, 0, 0, 10));
        }
        LinearLayout latest = sectionCard();
        latest.addView(text("Latest Reading", 18, WHITE, true),
                params(-1, -2, 0, 0, 0, 8));
        latestDetails = text("Waiting for the first reading...", 14, MUTED, false);
        latest.addView(latestDetails, params(-1, -2, 0, 0, 0, 0));
        pageContent.addView(latest, params(-1, -2, 0, 4, 0, 10));
        updateReadingViews();
    }

    private View metricCard(int index) {
        LinearLayout card = panel();
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setPadding(dp(12), dp(12), dp(8), dp(12));
        View indicator = new View(this);
        indicator.setBackground(shape(SENSOR_COLORS[index], SENSOR_COLORS[index], 3));
        card.addView(indicator, params(dp(4), -1, 0, 3, 10, 3));
        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        String unit = SENSOR_UNITS[index].isEmpty() ? "" : " (" + SENSOR_UNITS[index] + ")";
        TextView title = text(SENSOR_NAMES[index] + unit, 12, MUTED, false);
        details.addView(title, params(-1, -2, 0, 0, 0, 6));
        values[index] = text(latestReading == null ? "--" :
                number(latestReading, SENSOR_KEYS[index], SENSOR_DECIMALS[index]), 25, WHITE, true);
        details.addView(values[index], params(-1, -2, 0, 0, 0, 0));
        card.addView(details, new LinearLayout.LayoutParams(0, -2, 1));
        return card;
    }

    private void showSensorDataSection() {
        addInfoCard("Current sensor record",
                "Data received from the ESP32 at /sensorData/latest.");
        for (int i = 0; i < SENSOR_KEYS.length; i++) {
            LinearLayout card = sectionCard();
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.addView(text(SENSOR_NAMES[i], 15, MUTED, false),
                    new LinearLayout.LayoutParams(0, -2, 1));
            card.addView(text(formatSensorValue(i), 15, WHITE, true),
                    params(-2, -2, 8, 0, 0, 0));
            pageContent.addView(card, params(-1, -2, 0, 0, 0, 8));
        }
        addInfoCard("Device", latestReading == null ? "Waiting for ESP32 data." :
                latestReading.optString("deviceId", "--"));
        addInfoCard("Status", latestReading == null ? "--" :
                latestReading.optString("status", "--"));
        addInfoCard("Remarks", latestReading == null ? "--" :
                latestReading.optString("remarks", "--"));
        addInfoCard("Date/Time", formatTimestamp(latestReading));
    }

    private void showAlertsSection() {
        addInfoCard("Sensor alerts",
                "Alerts use limits you configure. No water-safety thresholds are assumed.");
        boolean configured = false;
        boolean outOfRange = false;
        boolean missingReadings = false;
        for (int i = 0; i < SENSOR_KEYS.length; i++) {
            float[] limits = getThreshold(i);
            if (Float.isNaN(limits[0]) && Float.isNaN(limits[1])) {
                continue;
            }
            configured = true;
            LinearLayout card = sectionCard();
            card.addView(text(SENSOR_NAMES[i], 16, WHITE, true),
                    params(-1, -2, 0, 0, 0, 4));
            if (latestReading == null || !latestReading.has(SENSOR_KEYS[i]) ||
                    latestReading.isNull(SENSOR_KEYS[i])) {
                missingReadings = true;
                card.addView(text("Waiting for a reading.", 14, MUTED, false),
                        params(-1, -2, 0, 0, 0, 0));
            } else {
                double reading = latestReading.optDouble(SENSOR_KEYS[i], Double.NaN);
                if (Double.isNaN(reading) || Double.isInfinite(reading)) {
                    missingReadings = true;
                    card.addView(text("ALERT: Sensor value is missing or invalid.",
                                    14, Color.rgb(255, 170, 170), false),
                            params(-1, -2, 0, 0, 0, 0));
                    outOfRange = true;
                    pageContent.addView(card, params(-1, -2, 0, 0, 0, 8));
                    continue;
                }
                String alert = thresholdAlert(reading, limits);
                boolean triggered = !alert.isEmpty();
                outOfRange |= triggered;
                card.addView(text(triggered ? "ALERT: " + alert + " (" + formatSensorValue(i) + ")" :
                                "Within your configured range (" + formatSensorValue(i) + ")",
                        14, triggered ? Color.rgb(255, 170, 170) :
                                Color.rgb(100, 237, 177), false),
                        params(-1, -2, 0, 0, 0, 0));
            }
            pageContent.addView(card, params(-1, -2, 0, 0, 0, 8));
        }
        if (!configured) {
            addInfoCard("No thresholds configured",
                    "Open Thresholds to set minimum or maximum values for sensors.");
        } else if (latestReading == null) {
            addInfoCard("Waiting for sensor data",
                    "Connect the ESP32 and check its Firebase upload.");
        } else if (!outOfRange && !missingReadings) {
            addInfoCard("Configured readings are in range",
                    "This is only a check against your own threshold settings.");
        }
    }

    private void showReportsSection() {
        addInfoCard("Report range",
                "The ESP32 replaces /sensorData/latest every five seconds. This report contains only the latest record; historical readings are not stored.");
        LinearLayout report = sectionCard();
        report.addView(text("Latest sensor summary", 18, WHITE, true),
                params(-1, -2, 0, 0, 0, 10));
        for (int i = 0; i < SENSOR_KEYS.length; i++) {
            report.addView(text(SENSOR_NAMES[i] + ": " + formatSensorValue(i),
                    14, MUTED, false), params(-1, -2, 0, 0, 0, 5));
        }
        report.addView(text("Device: " + (latestReading == null ? "--" :
                        latestReading.optString("deviceId", "--")) +
                        "\nDate/Time: " + formatTimestamp(latestReading),
                14, MUTED, false), params(-1, -2, 0, 8, 0, 10));
        Button share = button("Share latest report (CSV)");
        share.setEnabled(latestReading != null);
        share.setOnClickListener(v -> shareLatestReport());
        report.addView(share, params(-1, 48, 0, 4, 0, 0));
        pageContent.addView(report, params(-1, -2, 0, 0, 0, 10));
    }

    private void showThresholdsSection() {
        addInfoCard("Configure alert ranges",
                "Set limits for your own sensor calibration and project. These are not certified safety standards.");
        for (int i = 0; i < SENSOR_KEYS.length; i++) {
            final int sensor = i;
            float[] limits = getThreshold(i);
            LinearLayout row = sectionCard();
            row.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout description = new LinearLayout(this);
            description.setOrientation(LinearLayout.VERTICAL);
            description.addView(text(SENSOR_NAMES[i], 15, WHITE, true),
                    params(-1, -2, 0, 0, 0, 3));
            String unit = SENSOR_UNITS[i].isEmpty() ? "" : " " + SENSOR_UNITS[i];
            description.addView(text(formatLimit(limits[0]) + " to " +
                    formatLimit(limits[1]) + unit, 13, MUTED, false),
                    params(-1, -2, 0, 0, 0, 0));
            row.addView(description, new LinearLayout.LayoutParams(0, -2, 1));
            Button edit = button("Edit");
            edit.setTextSize(12);
            row.addView(edit, params(dp(68), 42, 6, 0, 0, 0));
            edit.setOnClickListener(v -> editThreshold(sensor));
            pageContent.addView(row, params(-1, -2, 0, 0, 0, 8));
        }
        Button clear = button("Clear all thresholds");
        clear.setOnClickListener(v -> {
            android.content.SharedPreferences.Editor editor =
                    getSharedPreferences(PREFERENCES, MODE_PRIVATE).edit();
            for (int i = 0; i < SENSOR_KEYS.length; i++) {
                editor.remove(thresholdKey(i, "min"));
                editor.remove(thresholdKey(i, "max"));
            }
            editor.apply();
            showSection(4);
        });
        pageContent.addView(clear, params(-1, 48, 0, 8, 0, 10));
    }

    private void addInfoCard(String title, String detail) {
        LinearLayout card = sectionCard();
        card.addView(text(title, 16, WHITE, true), params(-1, -2, 0, 0, 0, 4));
        card.addView(text(detail, 14, MUTED, false), params(-1, -2, 0, 0, 0, 0));
        pageContent.addView(card, params(-1, -2, 0, 0, 0, 8));
    }

    private LinearLayout sectionCard() {
        LinearLayout card = panel();
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        return card;
    }

    private void updateNavigationSelection() {
        if (navigationButtons == null) {
            return;
        }
        for (int i = 0; i < navigationButtons.length; i++) {
            boolean selected = i == currentSection;
            navigationButtons[i].setTextColor(selected ? ACCENT : MUTED);
            navigationButtons[i].setBackground(selected
                    ? shape(Color.rgb(18, 55, 78), Color.rgb(18, 55, 78), 13)
                    : shape(Color.TRANSPARENT, Color.TRANSPARENT, 13));
        }
    }

    private void editThreshold(int sensor) {
        float[] limits = getThreshold(sensor);
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), dp(4), dp(20), 0);
        EditText minimum = thresholdInput("Minimum (optional)", limits[0]);
        EditText maximum = thresholdInput("Maximum (optional)", limits[1]);
        form.addView(minimum);
        form.addView(maximum);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Thresholds: " + SENSOR_NAMES[sensor])
                .setMessage("Leave a limit blank to disable it. Values use " +
                        (SENSOR_UNITS[sensor].isEmpty() ? "pH" : SENSOR_UNITS[sensor]) + ".")
                .setView(form)
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Clear", (d, which) -> {
                    getSharedPreferences(PREFERENCES, MODE_PRIVATE).edit()
                            .remove(thresholdKey(sensor, "min"))
                            .remove(thresholdKey(sensor, "max")).apply();
                    showSection(4);
                })
                .setPositiveButton("Save", null)
                .create();
        dialog.setOnShowListener(ignored ->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                    String minText = minimum.getText().toString().trim();
                    String maxText = maximum.getText().toString().trim();
                    Float min = parseLimit(minText);
                    Float max = parseLimit(maxText);
                    if ((!minText.isEmpty() && min == null) ||
                            (!maxText.isEmpty() && max == null)) {
                        minimum.setError("Enter a valid number");
                        maximum.setError("Enter a valid number");
                        return;
                    }
                    if (min == null && max == null) {
                        minimum.setError("Set a limit, or choose Clear");
                        return;
                    }
                    if (min != null && max != null && min >= max) {
                        maximum.setError("Maximum must exceed minimum");
                        return;
                    }
                    android.content.SharedPreferences.Editor editor =
                            getSharedPreferences(PREFERENCES, MODE_PRIVATE).edit();
                    if (min == null) editor.remove(thresholdKey(sensor, "min"));
                    else editor.putFloat(thresholdKey(sensor, "min"), min);
                    if (max == null) editor.remove(thresholdKey(sensor, "max"));
                    else editor.putFloat(thresholdKey(sensor, "max"), max);
                    editor.apply();
                    dialog.dismiss();
                    showSection(4);
                }));
        dialog.show();
    }

    private EditText thresholdInput(String hint, float currentValue) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED |
                InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setHint(hint);
        if (!Float.isNaN(currentValue)) input.setText(Float.toString(currentValue));
        return input;
    }

    private Float parseLimit(String value) {
        if (value.isEmpty()) return null;
        try {
            float parsed = Float.parseFloat(value);
            return Float.isNaN(parsed) || Float.isInfinite(parsed) ? null : parsed;
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private float[] getThreshold(int sensor) {
        android.content.SharedPreferences preferences = getSharedPreferences(PREFERENCES, MODE_PRIVATE);
        String minKey = thresholdKey(sensor, "min");
        String maxKey = thresholdKey(sensor, "max");
        return new float[] {
                preferences.contains(minKey) ? preferences.getFloat(minKey, 0) : Float.NaN,
                preferences.contains(maxKey) ? preferences.getFloat(maxKey, 0) : Float.NaN
        };
    }

    private String thresholdKey(int sensor, String side) {
        return "threshold_" + SENSOR_KEYS[sensor] + "_" + side;
    }

    private String thresholdAlert(double reading, float[] limits) {
        if (!Float.isNaN(limits[0]) && reading < limits[0])
            return "below minimum " + formatLimit(limits[0]);
        if (!Float.isNaN(limits[1]) && reading > limits[1])
            return "above maximum " + formatLimit(limits[1]);
        return "";
    }

    private String formatLimit(float limit) {
        return Float.isNaN(limit) ? "--" :
                String.format(java.util.Locale.US, "%.2f", limit);
    }

    private String formatSensorValue(int index) {
        if (latestReading == null) return "--";
        String value = number(latestReading, SENSOR_KEYS[index], SENSOR_DECIMALS[index]);
        return SENSOR_UNITS[index].isEmpty() ? value : value + " " + SENSOR_UNITS[index];
    }

    private String formatTimestamp(JSONObject reading) {
        if (reading == null || !reading.has("timestamp") || reading.isNull("timestamp"))
            return "--";
        long timestamp = reading.optLong("timestamp", 0);
        if (timestamp <= 0) return "--";
        return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
                java.util.Locale.getDefault()).format(new java.util.Date(timestamp * 1000L));
    }

    private void shareLatestReport() {
        if (latestReading == null) return;
        StringBuilder csv = new StringBuilder("field,value,unit\n");
        for (int i = 0; i < SENSOR_KEYS.length; i++) {
            csv.append(SENSOR_NAMES[i]).append(',')
                    .append(number(latestReading, SENSOR_KEYS[i], SENSOR_DECIMALS[i]))
                    .append(',').append(SENSOR_UNITS[i]).append('\n');
        }
        csv.append("deviceId,").append(latestReading.optString("deviceId", "--")).append('\n')
                .append("status,").append(latestReading.optString("status", "--")).append('\n')
                .append("timestamp,").append(formatTimestamp(latestReading)).append('\n');
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/csv");
        share.putExtra(Intent.EXTRA_SUBJECT, "WQMS latest sensor report");
        share.putExtra(Intent.EXTRA_TEXT, csv.toString());
        startActivity(Intent.createChooser(share, "Share latest report"));
    }

    private void updateReadingViews() {
        if (latestReading == null) return;
        if (values != null) {
            for (int i = 0; i < values.length; i++) {
                if (values[i] != null)
                    values[i].setText(number(latestReading, SENSOR_KEYS[i], SENSOR_DECIMALS[i]));
            }
        }
        if (latestDetails != null) {
            latestDetails.setText("Device: " + latestReading.optString("deviceId", "--") +
                    "\nStatus: " + latestReading.optString("status", "--") +
                    "\nRemarks: " + latestReading.optString("remarks", "--") +
                    "\nDate/Time: " + formatTimestamp(latestReading));
        }
    }

    private void fetchReading() {
        if (requestInFlight || databaseUrl == null || idToken == null) {
            return;
        }
        requestInFlight = true;
        network.execute(() -> {
            try {
                String endpoint = databaseUrl + "/sensorData/latest.json?auth=" +
                        java.net.URLEncoder.encode(idToken, "UTF-8");
                Object payload = new JSONTokener(request(endpoint, "GET", null)).nextValue();
                if (payload instanceof JSONObject) {
                    JSONObject reading = (JSONObject) payload;
                    handler.post(() -> renderReading(reading, null));
                } else if (payload == JSONObject.NULL) {
                    handler.post(() -> renderReading(null, null));
                } else {
                    throw new JSONException("Firebase returned an unexpected sensor data shape.");
                }
            } catch (Exception exception) {
                handler.post(() -> renderReading(null, friendlyError(exception)));
            } finally {
                handler.post(() -> requestInFlight = false);
            }
        });
    }

    private void renderReading(JSONObject reading, String error) {
        if (isFinishing() || status == null) {
            return;
        }
        if (error != null) {
            setStatus("OFFLINE", Color.rgb(255, 170, 170),
                    Color.rgb(63, 30, 39), Color.rgb(121, 51, 65));
            addConnectionError(error);
            return;
        }
        if (reading == null || reading == JSONObject.NULL || reading.length() == 0) {
            latestReading = null;
            setStatus("NO DATA", Color.rgb(251, 191, 36),
                    Color.rgb(62, 49, 24), Color.rgb(121, 94, 37));
            showSection(currentSection);
            return;
        }

        latestReading = reading;
        setStatus("LIVE", GREEN, Color.rgb(12, 47, 43), Color.rgb(26, 102, 82));
        showSection(currentSection);
    }

    private void setStatus(String label, int foreground, int fill, int stroke) {
        if (status == null) {
            return;
        }
        status.setText(label);
        status.setTextColor(foreground);
        status.setBackground(shape(fill, stroke, 24));
    }

    private void addConnectionError(String message) {
        if (pageContent == null || isFinishing()) {
            return;
        }
        handler.post(() -> {
            if (pageContent == null || isFinishing()) {
                return;
            }
            if (connectionError == null) {
                connectionError = text(message, 13, Color.rgb(255, 170, 170), false);
                connectionError.setBackground(shape(Color.rgb(63, 30, 39),
                        Color.rgb(121, 51, 65), 14));
                connectionError.setPadding(dp(14), dp(12), dp(14), dp(12));
                pageContent.addView(connectionError, 1,
                        params(-1, -2, 0, 4, 0, 8));
            } else {
                connectionError.setText(message);
            }
        });
    }

    private String request(String endpoint, String method, String body) throws Exception {
        return request(endpoint, method, body, "application/json; charset=utf-8");
    }

    private String request(String endpoint, String method, String body,
                           String contentType) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(endpoint).openConnection();
            connection.setRequestMethod(method);
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(12000);
            connection.setRequestProperty("Accept", "application/json");
            if (body != null) {
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", contentType);
                byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(bytes);
                }
            }

            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300
                    ? connection.getInputStream()
                    : connection.getErrorStream();
            String response = readAll(stream);
            if (code < 200 || code >= 300) {
                String firebaseMessage = response;
                try {
                    JSONObject error = new JSONObject(response).optJSONObject("error");
                    if (error != null) {
                        firebaseMessage = error.optString("message", response);
                    }
                } catch (JSONException parseError) {
                    // Keep the HTTP error body when Firebase returns non-JSON.
                }
                throw new java.io.IOException("Firebase HTTP " + code + ": " + firebaseMessage);
            }
            return response;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private String readAll(InputStream stream) throws Exception {
        if (stream == null) {
            return "";
        }
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
        }
        return result.toString();
    }

    private String friendlyError(Exception exception) {
        String message = exception.getMessage();
        if (message == null || message.isEmpty()) {
            return "Connection failed. Check your internet and Firebase settings.";
        }
        if (message.contains("INVALID_PASSWORD") ||
                message.contains("INVALID_LOGIN_CREDENTIALS") ||
                message.contains("INVALID_EMAIL")) {
            return "Firebase sign-in was rejected. Check the email and password in Authentication > Users.";
        }
        if (message.contains("EMAIL_NOT_FOUND")) {
            return "This email is not in Firebase Authentication > Users. Add it there first.";
        }
        if (message.contains("OPERATION_NOT_ALLOWED")) {
            return "Enable Email/Password in Firebase Console > Authentication > Sign-in method.";
        }
        if (message.contains("USER_DISABLED")) {
            return "This Firebase user is disabled. Enable the user in Authentication > Users.";
        }
        if (message.contains("TOO_MANY_ATTEMPTS_TRY_LATER")) {
            return "Firebase temporarily blocked sign-in attempts. Wait a few minutes and try again.";
        }
        if (message.contains("API_KEY_INVALID")) {
            return "Firebase rejected the API key. Check the Web API key in Project settings > General.";
        }
        if (message.contains("Permission denied") || message.contains("PermissionDenied")) {
            return "Firebase denied access. Check Realtime Database read rules.";
        }
        if (message.contains("TOKEN_EXPIRED") || message.contains("INVALID_ID_TOKEN")) {
            return "Firebase session expired. Reconnecting; if it continues, sign in again.";
        }
        return message;
    }

    private String number(JSONObject object, String key, int decimals) {
        if (!object.has(key) || object.isNull(key)) {
            return "--";
        }
        Object value = object.opt(key);
        if (!(value instanceof Number)) {
            return "--";
        }
        return String.format(java.util.Locale.US, "%." + decimals + "f", ((Number) value).doubleValue());
    }

    private LinearLayout createRoot() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(BACKGROUND);
        return layout;
    }

    private ScrollView wrap(View content) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        return scroll;
    }

    private LinearLayout panel() {
        LinearLayout layout = new LinearLayout(this);
        layout.setBackground(shape(PANEL, BORDER, 20));
        layout.setElevation(dp(2));
        return layout;
    }

    private GradientDrawable shape(int fill, int stroke, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private GradientDrawable gradientShape(int[] colors, int stroke, int radius) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, colors);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) {
            view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        }
        return view;
    }

    private Button button(String label) {
        Button view = new Button(this);
        view.setText(label);
        view.setTextColor(Color.WHITE);
        view.setTextSize(15);
        view.setAllCaps(false);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setBackground(shape(Color.rgb(14, 102, 139), Color.rgb(29, 140, 180), 14));
        view.setElevation(dp(2));
        return view;
    }

    private void addField(LinearLayout form, String label, String hint, boolean passwordField) {
        TextView title = text(label, 13, MUTED, true);
        form.addView(title, params(-1, -2, 0, 0, 0, 4));
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(14);
        input.setTextColor(WHITE);
        input.setHintTextColor(Color.rgb(112, 132, 162));
        input.setHint(hint);
        input.setPadding(dp(14), 0, dp(14), 0);
        input.setBackground(shape(Color.rgb(7, 15, 32), BORDER, 12));
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            input.setAutofillHints(passwordField ? new String[] {
                    android.view.View.AUTOFILL_HINT_PASSWORD
            } : (("Email".equals(label) || "Email address".equals(label)) ? new String[] {
                    android.view.View.AUTOFILL_HINT_EMAIL_ADDRESS
            } : new String[0]));
        }
        if (passwordField) {
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        } else if ("Email".equals(label) || "Email address".equals(label)) {
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        } else {
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        }

        android.content.SharedPreferences preferences = getSharedPreferences(PREFERENCES, MODE_PRIVATE);
        if ("Firebase Realtime Database URL".equals(label) ||
                "Realtime Database URL".equals(label)) {
            input.setText(preferences.getString("databaseUrl", DEFAULT_DATABASE_URL));
        } else if ("Firebase Web API key".equals(label) || "Web API key".equals(label)) {
            input.setText(preferences.getString("apiKey", DEFAULT_API_KEY));
        } else if ("Email".equals(label) || "Email address".equals(label)) {
            input.setText(preferences.getString("email", ""));
        }
        form.addView(input, params(-1, 50, 0, 0, 0, 12));
    }

    private final class WatermarkView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path droplet = new Path();

        WatermarkView() {
            super(MainActivity.this);
            setContentDescription("Water droplet illustration");
            setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float density = getResources().getDisplayMetrics().density;
            float centerX = getWidth() / 2f;
            float centerY = getHeight() / 2f;
            float unit = density;

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(35, 56, 189, 248));
            canvas.drawCircle(centerX, centerY, 35 * unit, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.2f * unit);
            paint.setColor(Color.argb(90, 91, 214, 242));
            canvas.drawCircle(centerX, centerY, 31 * unit, paint);
            canvas.drawCircle(centerX, centerY, 24 * unit, paint);

            float dropWidth = 25 * unit;
            float dropHeight = 34 * unit;
            float tipY = centerY - dropHeight * 0.53f;
            float baseY = centerY + dropHeight * 0.42f;
            droplet.reset();
            droplet.moveTo(centerX, tipY);
            droplet.cubicTo(centerX - 4 * unit, centerY - 2 * unit,
                    centerX - dropWidth * 0.56f, centerY + 4 * unit,
                    centerX - dropWidth * 0.48f, centerY + 12 * unit);
            droplet.cubicTo(centerX - dropWidth * 0.42f, baseY,
                    centerX + dropWidth * 0.42f, baseY,
                    centerX + dropWidth * 0.48f, centerY + 12 * unit);
            droplet.cubicTo(centerX + dropWidth * 0.56f, centerY + 4 * unit,
                    centerX + 4 * unit, centerY - 2 * unit,
                    centerX, tipY);
            droplet.close();
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(ACCENT);
            canvas.drawPath(droplet, paint);
            paint.setColor(Color.argb(190, 224, 250, 255));
            canvas.drawCircle(centerX - 5 * unit, centerY + 5 * unit, 2 * unit, paint);
        }
    }

    private EditText lastInput(LinearLayout parent) {
        return (EditText) parent.getChildAt(parent.getChildCount() - 1);
    }

    private LinearLayout.LayoutParams params(int width, int height, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(width, height);
        layout.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return layout;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
