$ErrorActionPreference = "Stop"

$source = Join-Path $PSScriptRoot "Program.cs"
$outputDirectory = Join-Path $PSScriptRoot "dist"
$output = Join-Path $outputDirectory "WQMS-Dashboard-Firebase.exe"
$compiler = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"

if (-not (Test-Path $compiler)) {
    throw "The .NET Framework 4.x C# compiler was not found at $compiler."
}

if (-not (Test-Path $source)) {
    throw "Application source was not found at $source."
}

New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
& $compiler /nologo /target:winexe /optimize+ /out:$output /reference:System.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Web.Extensions.dll $source
if ($LASTEXITCODE -ne 0) {
    throw "C# compilation failed with exit code $LASTEXITCODE."
}

Write-Output "Created $output"
